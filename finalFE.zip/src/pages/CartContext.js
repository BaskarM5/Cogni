import React, { createContext, useState } from 'react';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (book) => { // Parameter changed to 'book' for clarity
    setCartItems((prevItems) => {
      // Use book.bookid (the unique identifier from your backend Book model)
      // to correctly check if the book already exists in the cart.
      const existingItem = prevItems.find((cartItem) => cartItem.bookid === book.bookid);

      if (existingItem) {
        // If the book exists, increase its quantity
        return prevItems.map((cartItem) =>
          cartItem.bookid === book.bookid
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        // If the book does not exist, add it as a new item with quantity 1
        // Ensure that new items added to cart have a quantity property
        return [...prevItems, { ...book, quantity: 1 }];
      }
    });
    console.log(`Adding ${book.title} to cart.`);
  };

  const updateQuantity = (bookId, newQuantity) => { // Parameter changed to 'bookId' for clarity
    setCartItems((prevItems) => {
      // Ensure quantity doesn't go below 1
      const quantityToSet = Math.max(1, newQuantity); 
      return prevItems.map((item) =>
        item.bookid === bookId
          ? { ...item, quantity: quantityToSet }
          : item
      );
    });
  };

  const removeFromCart = (bookId) => { // Parameter changed to 'bookId' for clarity
    setCartItems((prevItems) => prevItems.filter((item) => item.bookid !== bookId));
  };

  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider value={{ cartItems, addToCart, updateQuantity, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};

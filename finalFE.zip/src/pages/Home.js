import React from "react";
import { useNavigate } from "react-router-dom";
import "../Styles/Home.css";

const Home = () => {
    const navigate = useNavigate(); // ✅ Navigation hook

    return (
        <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", backgroundColor: "#FFFFFF" }}>
            {/* Top Bar */}
            <div style={{ position: "absolute", top: "0", width: "100%", backgroundColor: "#2D093F", padding: "40px 30px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h1 style={{ color: "white", margin: 0 }}>E-BOOK STORE</h1>
                <div style={{ display: "flex", gap: "10px", color:"#ffffff" }}> {/* ✅ Buttons placed side by side */}
                    <button className="btn-custom" onClick={() => navigate("/login")}>Login</button>
                    <button className="btn-custom" onClick={() => navigate("/register")}>Register</button>
                </div>
            </div>
            <br/>
            <br/>
            <br/>
            {/* Center Image */}
            <div style={{ marginTop: "80px" }}>
                <img src="/homepage image.png" alt="E-Book Store" style={{ width: "400px", height: "auto", borderRadius: "10px" }} />
            </div>
        </div>
    );
};

export default Home;

import React, { useState, useEffect } from "react"; // Removed useContext as CartContext is not directly used here
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirection
import "../Styles/orders.css";// Ensure your orders.css is correctly linked and provides necessary styling

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); // Initialize useNavigate hook

  useEffect(() => {
    const fetchUserOrders = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem('jwtToken');
        const userEmail = localStorage.getItem('userEmail'); // Get the logged-in user's email

        if (!token || !userEmail) {
          setError("Authentication details missing. Please log in.");
          setLoading(false);
          // Redirect to login page if no token/email
          navigate("/login"); 
          return;
        }

        // Endpoint: Assuming you have a backend endpoint like /api/order/user/{userEmail}
        const response = await fetch(`http://localhost:1021/api/order/user/${userEmail}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}` // Include the JWT token
          }
        });

        if (!response.ok) {
          let errorMessage = `HTTP error! Status: ${response.status}.`;
          const errorBody = await response.text(); 
          try {
            const errorJson = JSON.parse(errorBody);
            errorMessage = errorJson.message || errorJson.error || errorBody;
          } catch (jsonParseError) {
            errorMessage = errorBody;
          }
          console.error(`Failed to fetch orders: ${errorMessage}`);
          setError(`Failed to fetch orders: ${response.status} - ${errorMessage}`);
          // Handle specific auth errors if needed
          if (response.status === 401 || response.status === 403) {
            localStorage.removeItem('jwtToken');
            localStorage.removeItem('userRole');
            localStorage.removeItem('userEmail');
            navigate("/login");
          }
          return;
        }

        // If the backend returns 204 No Content for no orders, handle it
        if (response.status === 204) {
          setOrders([]); // Set orders to empty array if no content
          return;
        }

        const data = await response.json();
        // The backend returns a list of Order objects.
        // Each Order object contains a list of OrderItem objects.
        setOrders(data);
        console.log("Fetched orders:", data);

      } catch (error) {
        console.error("Error fetching orders:", error);
        setError("An unexpected error occurred while fetching your orders. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchUserOrders();
  }, [navigate]); // Add navigate to dependency array

  if (loading) {
    return (
      <div className="orders-container">
        <h2>Your Orders</h2>
        <p>Loading your orders...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="orders-container">
        <h2>Your Orders</h2>
        <p className="error-message">Error: {error}</p>
        <button
            onClick={() => navigate("/login")}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Go to Login
          </button>
      </div>
    );
  }
return(
  <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
      {/* Sidebar Navigation */}
      <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
          <h3 className="text-center">User</h3>
          
          <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/customer-dashboard")}>
              Home
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/cart")}>
              Cart
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
              onClick={() => navigate("/orders")}>
              Orders
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/")}>
              Logout
          </button>
      </div>

      {/* Main Orders Content */}
      <div className="orders-container">
        <h2>Your Orders</h2>
        {loading ? (
          <p>Loading your orders...</p>
        ) : error ? (
          <>
            <p className="error-message">Error: {error}</p>
            <button onClick={() => navigate("/login")} className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
              Go to Login
            </button>
          </>
        ) : orders.length === 0 ? (
          <p>You haven't placed any orders yet.</p>
        ) : (
          orders.map((order) => (
            <div key={order.orderid} className="order-summary-card">
              <h3>Order ID: {order.orderid}</h3>
              <p>Order Date: {order.orderDate}</p>
              <p>Status: {order.status}</p>
              <p className="total-amount">Total Amount: ${order.totalAmount ? order.totalAmount.toFixed(2) : '0.00'}</p>
              
              <div className="order-items-list">
                <h4>Items:</h4>
                {order.orderItems && order.orderItems.length > 0 ? (
                  order.orderItems.map((item) => (
                    <div key={item.id} className="order-item-detail">
                      <img 
                        src={item.book?.imageData ? `data:image/jpeg;base64,${item.book.imageData}` : "https://placehold.co/60x80/cccccc/000000?text=No+Image"} 
                        alt={item.book?.title || 'N/A'} 
                        className="order-item-image" 
                      />
                      <div className="order-item-info">
                        <p>Book: {item.book?.title || 'N/A'}</p>
                        <p>Author: {item.book?.author?.name || 'Unknown'}</p>
                        <p>Quantity: {item.quantity}</p>
                        <p>Price at Order: ${item.priceAtOrder ? item.priceAtOrder.toFixed(2) : 'N/A'}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p>No items found for this order.</p>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Orders;
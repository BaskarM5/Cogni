import React from "react";
import "../Styles/BookDetailsModal.css";

const BookDetailsModal = ({ book, onClose, onAddToCart }) => {
  if (!book) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="modal-close" onClick={onClose}>×</button>
        {/* Display image from Base64 data in the modal */}
        {/* Fallback for cases where imageData might be missing or invalid Base64 */}
        <img
          src={book.imageData ? `data:image/jpeg;base64,${book.imageData}` : "https://placehold.co/200x300/cccccc/000000?text=No+Image"}
          alt={book.title}
          className="modal-image"
        />
        <h2 className="modal-title">{book.title}</h2>
        {/* Correctly access the author's name from the nested object */}
        <p className="modal-author">by {book.author ? book.author.name : 'Unknown Author'}</p>
        <p className="modal-description">{book.description}</p>
        <p className="modal-price">Price: ${book.price ? book.price.toFixed(2) : 'N/A'}</p>
        <button className="modal-add-button" onClick={() => onAddToCart(book)}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default BookDetailsModal;

import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../Styles/Login.css";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    try {
      console.log("Attempting login with:", formData);
      const response = await axios.post("http://localhost:1021/auth/login", formData);
      console.log("Login response data:", response.data);

      // --- CRUCIAL: Store token & role securely in localStorage ---
      if (response.data?.token && response.data?.role) {
        localStorage.setItem("jwtToken", response.data.token);
        localStorage.setItem("userRole", response.data.role);
        localStorage.setItem("userEmail", formData.email);
        console.log("Token and Role stored in localStorage.");
      } else {
        console.warn("Login response missing token or role:", response.data);
        setError("Invalid login response. Please contact support.");
        return;
      }

      // Redirect based on role
      setMessage("Login successful! Redirecting...");
      setTimeout(() => {
        if (response.data.role === "ADMIN") {
          navigate("/admin-dashboard");
        } else if (response.data.role === "USER") {
          navigate("/customer-dashboard");
        } else {
          setError("Invalid role. Please contact support.");
        }
      }, 1500);

    } catch (err) {
      console.error("Login failed:", err);

      if (err.response?.status === 403) {
        setError("Unauthorized! Please check your credentials.");
      } else if (err.response?.status === 401) {
        setError("Session expired. Please log in again.");
      } else {
        setError(err.response?.data?.error || "An error occurred during login.");
      }
    }
  };

  return (
      <div className="login-container">
        <div className="login-card">
          <h2>Login</h2>
          <br/>

          {message && <div className="alert-success">{message}</div>}
          {error && <div className="alert-danger">{error}</div>}
          <form onSubmit={handleSubmit}>
            <label>Email:</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} required />
  <br/>
  <br/>
            <label>Password:</label>
            <input type="password" name="password" value={formData.password} onChange={handleChange} required />
  <br/>
  <br/>
  <br/>
            <button type="submit">Login</button>
          </form>
        </div>
      </div>
    );
};

export default Login;

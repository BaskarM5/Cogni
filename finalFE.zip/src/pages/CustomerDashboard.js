import React, { useState, useEffect, useContext } from "react";
import BookCard from "./BookCard";
import BookDetailsModal from "./BookDetailsModal";
import { CartContext } from "./CartContext";
import { useNavigate } from "react-router-dom";
import "../Styles/styles.css"; // Ensure your styles.css is correctly linked and provides necessary styling

const CustomerDashboard = () => {
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [searchTerm, setSearchTerm] = useState(""); // State for the search input
  const [loading, setLoading] = useState(true); // State for loading
  const [error, setError] = useState(null); // State for errors
  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate(); // Initialize useNavigate hook

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        setLoading(true); // Set loading to true at the start of fetch
        setError(null); // Clear previous errors

        // Retrieve JWT token from localStorage (assuming it's stored here after login)
        const token = localStorage.getItem("jwtToken");

        if (!token) {
          // If no token is found, set an error and stop
          setError("Authentication token not found. Please log in.");
          setLoading(false);
          console.error("Error: Authentication token not found.");
          // Optionally redirect to login if no token
          navigate("/login");
          return;
        }

        const response = await fetch("http://localhost:1021/api/books/all", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, // Include the JWT token here
          },
        });

        if (!response.ok) {
          // Handle non-2xx responses (like 403 Forbidden, 401 Unauthorized, 500 Internal Server Error)
          const errorText = await response.text(); // Read response as text for better error messages
          console.error(`HTTP error! status: ${response.status}, message: ${errorText}`);
          setError(`Failed to fetch books: ${response.status} - ${errorText || response.statusText}`);
          // If 401/403, might need to clear token and redirect to login
          if (response.status === 401 || response.status === 403) {
            localStorage.removeItem("jwtToken");
            localStorage.removeItem("userRole");
            navigate("/login");
          }
          return; // Stop execution if response is not ok
        }

        const data = await response.json();
        setBooks(data);
        console.log("Fetched books:", data);
      } catch (error) {
        console.error("Error fetching books:", error);
        setError("An unexpected error occurred while fetching books. Please try again.");
      } finally {
        setLoading(false); // Set loading to false once fetch is complete (success or error)
      }
    };

    fetchBooks();
  }, [navigate]); // Add navigate to dependency array

  const handleViewDetails = (book) => {
    setSelectedBook(book);
  };

  const handleAddToCart = (book) => {
    addToCart(book);
    setSelectedBook(null);
  };

  // Filter books based on searchTerm
  const filteredBooks = books.filter((book) =>
    // Ensure book.author and book.author.name exist before trying to access it
    // Search by title or author's name
    (book.title && book.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (book.author && book.author.name && book.author.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Render states
  if (loading) {
    return (
      <div className="dashboard-layout">
        <div className="main-content flex items-center justify-center min-h-screen">
          <p className="text-lg text-gray-700">Loading books...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-layout">
        <div className="main-content flex flex-col items-center justify-center min-h-screen bg-red-100 p-4 rounded-lg shadow-md m-4 text-center">
          <p className="text-lg text-red-700 font-semibold mb-2">Error: {error}</p>
          <p className="text-md text-red-600">
            Please ensure your backend server is running, you are logged in, and your JWT token is valid.
          </p>
          {/* Keep the logout button in error state, as it's useful there */}
          <button
            onClick={() => {
              localStorage.removeItem("jwtToken");
              localStorage.removeItem("userRole");
              navigate("/login");
            }}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
      {/* Sidebar Navigation */}
      <div
        style={{
          backgroundColor: "#2D093F",
          width: "300px",
          padding: "20px",
          color: "white",
          minHeight: "100vh",
        }}
      >
        <h3 className="text-center">User</h3>

        <button
          className="btn w-100 mt-5"
          style={{ backgroundColor: "#4A0F67", color: "white" }}
          onClick={() => navigate("/customer-dashboard")}
        >
          Home
        </button>
        <button
          className="btn w-100 mt-4"
          style={{ backgroundColor: "#2D093F", color: "white" }}
          onClick={() => navigate("/cart")}
        >
          Cart
        </button>
        <button
          className="btn w-100 mt-4"
          style={{ backgroundColor: "#2D093F", color: "white" }}
          onClick={() => navigate("/orders")}
        >
          Orders
        </button>
        <button
          className="btn w-100 mt-4"
          style={{ backgroundColor: "#2D093F", color: "white" }}
          onClick={() => navigate("/")}
        >
          Logout
        </button>
      </div>

      <div className="main-content">
        <h1>Welcome to Digital BookStore!</h1>

        {/* Center Image */}
        <div style={{ marginTop: "30px", marginBottom: "17px" }}>
          <img
            src="/homeuser.jpg"
            alt="E-Book Store"
            style={{ width: "1000px", height: "270px", borderRadius: "10px" }}
          />
        </div>

        {/* Search Input Field - Centered with Shadow */}
        <div
          style={{
            display: "flex",
            justifyContent: "center", // Center the content horizontally
            marginBottom: "20px", // Add some space below the search bar
            marginTop: "20px" // Add some space above the search bar
          }}
        >
          <input
            type="text"
            placeholder="Search books by title or author..."
            className="form-control" // Using Bootstrap classes for basic styling
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: "100%",
              maxWidth: "600px", // Limit max width for better aesthetics
              padding: "10px",
              borderRadius: "8px", // Slightly more rounded corners
              border: "1px solid #ddd", // Lighter border
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow
              outline: "none", // Remove default outline on focus
              transition: "box-shadow 0.3s ease-in-out", // Smooth transition for shadow
            }}
          />
        </div>


        <h2 className="book-list-heading">Available Books</h2>
        <div className="book-grid">
          {filteredBooks.length > 0 ? (
            filteredBooks.map((book) => (
              <BookCard key={book.bookid} book={book} onViewDetail={handleViewDetails} />
            ))
          ) : (
            <p>No books found for "{searchTerm}".</p>
          )}
        </div>
      </div>

      {selectedBook && (
        <BookDetailsModal
          book={selectedBook}
          onClose={() => setSelectedBook(null)}
          onAddToCart={handleAddToCart}
        />
      )}
    </div>
  );
};

export default CustomerDashboard;
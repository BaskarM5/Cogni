import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:1021/api/categories"; // Your API endpoint

const CategoryManagement = () => {
    const navigate = useNavigate();
    const [categories, setCategories] = useState([]);
    const [newCategory, setNewCategory] = useState({ name: "" });
    const [alertMessage, setAlertMessage] = useState(null);
    const [editingCategoryId, setEditingCategoryId] = useState(null); // Track editing category

    // Retrieve token
    const getAuthToken = () => localStorage.getItem("jwtToken");

    // Fetch all categories on component mount
    useEffect(() => {
        fetchCategories();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await fetch(API_URL, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                }
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.status}`);
            }

            const data = await response.json();
            setCategories(data);
        } catch (error) {
            console.error("Error fetching categories:", error);
        }
    };

    const showAlert = (message) => {
        setAlertMessage(message);
        setTimeout(() => setAlertMessage(null), 2000);
    };

    const addOrUpdateCategory = async () => {
        try {
            const method = editingCategoryId ? "PUT" : "POST";
            const url = editingCategoryId ? `${API_URL}/${editingCategoryId}` : API_URL;

            const response = await fetch(url, {
                method,
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(newCategory),
            });

            if (response.ok) {
                fetchCategories();
                setNewCategory({ name: "" });
                setEditingCategoryId(null);
                showAlert(editingCategoryId ? "Category updated successfully!" : "Category added successfully!");
            }
        } catch (error) {
            console.error("Error saving category:", error);
        }
    };

    const startEditingCategory = (category) => {
        setNewCategory({ name: category.name });
        setEditingCategoryId(category.id);
    };

    const deleteCategory = async (id) => {
        try {
            await fetch(`${API_URL}/${id}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                }
            });

            fetchCategories();
            showAlert("Category deleted successfully!");
        } catch (error) {
            console.error("Error deleting category:", error);
        }
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            {/* Sidebar Navigation */}
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
                <h3 className="text-center">Admin</h3>
                
                <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/admin-dashboard")}>
                    Dashboard
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/book-management")}>
                    Manage Books
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/author-management")}>
                    Manage Authors
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
                    onClick={() => navigate("/category-management")}>
                    Manage Categories
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/inventory-management")}>
                    Manage Inventory
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/user-management")}>
                    Manage Users
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => {
                        localStorage.removeItem("jwtToken");
                        sessionStorage.clear();
                        navigate("/");
                    }}>
                    Logout
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Categories</h2>
<br/>
                {alertMessage && (
                    <div className="alert alert-success text-center">{alertMessage}</div>
                )}
<br/>
                {/* Add/Edit Category Form */}
                <div className="mb-3">
                    <input type="text" placeholder="Category Name" className="form-control mb-2"
                        value={newCategory.name} onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })} />
                    <br/>
                    <button className="btn btn-success" onClick={addOrUpdateCategory}>
                        {editingCategoryId ? "Update Category" : "Add Category"}
                    </button>
                </div>
                <br/>
                <br/>
                {/* Category Table */}
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Category ID</th>
                            <th>Category Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {categories.map(category => (
                            <tr key={category.id}>
                                <td>{category.id}</td>
                                <td>{category.name}</td>
                                <td>
                                    <button className="btn btn-warning" onClick={() => startEditingCategory(category)}>Edit</button>
                                    <br/><br/>
                                    <button className="btn btn-danger" onClick={() => deleteCategory(category.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default CategoryManagement;

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// API endpoints
const API_BOOKS_URL = "http://localhost:1021/api/books";

const AdminDashboard = () => {
    const navigate = useNavigate();

    // Renamed state variable from 'recentlyAddedBooks' to 'allBooks' for clarity
    const [allBooks, setAllBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const getAuthToken = () => {
        const token = localStorage.getItem("jwtToken");
        return token;
    };

    useEffect(() => {
        const fetchAllBooksData = async () => { // Renamed function for clarity
            try {
                setLoading(true);
                setError(null);

                const token = getAuthToken();
                if (!token) {
                    setError("Authentication token not found. Please log in.");
                    setLoading(false);
                    navigate("/"); // Redirect to login if no token is found
                    return;
                }

                const response = await fetch(`${API_BOOKS_URL}/all`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    console.error(`Error fetching books: ${response.status} - ${errorText}`);
                    if (response.status === 401 || response.status === 403) {
                        setError("Session expired or unauthorized. Please log in again.");
                        localStorage.removeItem("jwtToken");
                        localStorage.removeItem("userRole");
                        navigate("/"); // Redirect to login
                    } else {
                        throw new Error(`Failed to fetch books: ${response.status} - ${errorText}`);
                    }
                }

                const data = await response.json();
                console.log("Fetched all books for admin dashboard:", data);

                // Sort books by publicationDate (or createdAt, addedDate) in descending order
                // This sorting is kept, but no slicing is performed.
                const sortedBooks = data.sort((a, b) => {
                    const dateA = a.publicationDate ? new Date(a.publicationDate).getTime() : 0;
                    const dateB = b.publicationDate ? new Date(b.publicationDate).getTime() : 0;
                    return dateB - dateA; // Descending order (most recent first)
                });

                // Set all fetched and sorted books to the state
                setAllBooks(sortedBooks); // REMOVED .slice(0, 5)

            } catch (err) {
                console.error("Failed to fetch all books:", err);
                setError(`Error loading books: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };

        fetchAllBooksData(); // Call the updated fetch function
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem("jwtToken");
        localStorage.removeItem("userRole");
        sessionStorage.clear();
        navigate("/");
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            {/* Sidebar Navigation */}
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}>
                <h3 className="text-center">Admin</h3>

                <button className="btn w-100 mt-5" style={{ backgroundColor: "#4A0F67", color: "white" }}
                    onClick={() => navigate("/admin-dashboard")}>
                    Dashboard
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/book-management")}>
                    Manage Books
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/author-management")}>
                    Manage Authors
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/category-management")}>
                    Manage Categories
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/inventory-management")}>
                    Manage Inventory
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/user-management")}>
                    Manage Users
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={handleLogout}>
                    Logout
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h1 className="text-center">Hello Admin,</h1>
                <br />

                <h6 className="text-center">
                    Your central hub for streamlined management!
                </h6>

                <div className="mt-5">
                    {/* Changed heading to reflect displaying all books */}
                    <h3 className="text-center mb-4">All Books in the System</h3>
                    {loading && (
                        <div className="text-center text-secondary">Loading books...</div>
                    )}
                    {error && (
                        <div className="alert alert-danger text-center">{error}</div>
                    )}
                    {!loading && !error && (
                        <ul className="list-group">
                            {/* Changed iteration from 'recentlyAddedBooks' to 'allBooks' */}
                            {allBooks.length > 0 ? (
                                allBooks.map((book) => (
                                    <li
                                        key={book.bookid}
                                        className="list-group-item d-flex align-items-center justify-content-start my-2"
                                        style={{ boxShadow: "0 2px 5px rgba(0,0,0,0.1)", borderRadius: "8px" }}
                                    >
                                        <img
                                            // Construct the src directly from Base64 imageData
                                            // IMPORTANT: Ensure the MIME type (image/jpeg) matches your actual image type.
                                            src={book.imageData ? `data:image/jpeg;base64,${book.imageData}` : '/images/placeholder.jpg'}
                                            alt={book.title || 'Book Cover'}
                                            style={{
                                                width: '80px',
                                                minWidth: '80px',
                                                height: '100px',
                                                minHeight: '100px',
                                                objectFit: 'cover',
                                                marginRight: '20px',
                                                borderRadius: '5px',
                                                backgroundColor: '#f0f0f0'
                                            }}
                                            onError={(e) => {
                                                console.warn(`AdminDashboard: Image failed to load from Base64 for book ID ${book.bookid}. Falling back to static placeholder.`);
                                                e.target.onerror = null;
                                                e.target.src = '/images/placeholder.jpg';
                                            }}
                                        />
                                        <div>
                                            <h5 className="mb-1"><strong>{book.title}</strong></h5>
                                            <p className="mb-1 text-muted">by {book.author ? book.author.name : 'Unknown Author'}</p>
                                            <p className="mb-1">ISBN: {book.isbn || 'N/A'}</p>
                                            <p className="mb-0">Price: ${book.price ? book.price.toFixed(2) : 'N/A'}</p>
                                        </div>
                                    </li>
                                ))
                            ) : (
                                <li className="list-group-item text-center">No books found in the system.</li>
                            )}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
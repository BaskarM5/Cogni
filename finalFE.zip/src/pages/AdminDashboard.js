import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";

// API endpoints
const API_BOOKS_URL = "http://localhost:1021/api/books";

const AdminDashboard = () => {
    const navigate = useNavigate();

    const [allBooks, setAllBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    const getAuthToken = () => {
        const token = localStorage.getItem("jwtToken");
        return token;
    };

    useEffect(() => {
        const fetchAllBooksData = async () => {
            try {
                setLoading(true);
                setError(null);

                const token = getAuthToken();
                if (!token) {
                    setError("Authentication token not found. Please log in.");
                    setLoading(false);
                    navigate("/");
                    return;
                }

                const response = await fetch(`${API_BOOKS_URL}/all`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    console.error(`Error fetching books: ${response.status} - ${errorText}`);
                    if (response.status === 401 || response.status === 403) {
                        setError("Session expired or unauthorized. Please log in again.");
                        localStorage.removeItem("jwtToken");
                        localStorage.removeItem("userRole");
                        navigate("/");
                    } else {
                        throw new Error(`Failed to fetch books: ${response.status} - ${errorText}`);
                    }
                }

                const data = await response.json();
                console.log("Fetched all books for admin dashboard:", data);

                const sortedBooks = data.sort((a, b) => {
                    const dateA = a.publicationDate ? new Date(a.publicationDate).getTime() : 0;
                    const dateB = b.publicationDate ? new Date(b.publicationDate).getTime() : 0;
                    return dateB - dateA;
                });

                setAllBooks(sortedBooks);

            } catch (err) {
                console.error("Failed to fetch all books:", err);
                setError(`Error loading books: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };

        fetchAllBooksData();
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem("jwtToken");
        localStorage.removeItem("userRole");
        sessionStorage.clear();
        navigate("/");
    };

    const filteredBooks = useMemo(() => {
        if (!searchTerm) {
            return allBooks;
        }

        const lowerCaseSearchTerm = searchTerm.toLowerCase();

        return allBooks.filter(book => {
            const matchesTitle = book.title && book.title.toLowerCase().includes(lowerCaseSearchTerm);
            const matchesAuthor = book.author && book.author.name && book.author.name.toLowerCase().includes(lowerCaseSearchTerm);
            const matchesCategory = book.category && book.category.name && book.category.name.toLowerCase().includes(lowerCaseSearchTerm);
            const matchesIsbn = book.isbn && String(book.isbn).toLowerCase().includes(lowerCaseSearchTerm);
            const matchesDescription = book.description && book.description.toLowerCase().includes(lowerCaseSearchTerm);

            return matchesTitle || matchesAuthor || matchesCategory || matchesIsbn || matchesDescription;
        });
    }, [allBooks, searchTerm]);

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            {/* Sidebar Navigation */}
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}>
                <h3 className="text-center">Admin</h3>

                <button className="btn w-100 mt-5" style={{ backgroundColor: "#4A0F67", color: "white" }}
                    onClick={() => navigate("/admin-dashboard")}>
                    Dashboard
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/book-management")}>
                    Manage Books
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/author-management")}>
                    Manage Authors
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/category-management")}>
                    Manage Categories
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/inventory-management")}>
                    Manage Inventory
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/user-management")}>
                    Manage Users
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={handleLogout}>
                    Logout
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h1 className="text-center">Hello Admin,</h1>
                {/* Added text below Hello Admin */}
                <p className="text-center mt-3" style={{ fontSize: '1.1em', color: '#555' }}>
                    Welcome to your Book Store Management Portal! Here you can oversee all books, manage inventory, and handle operations efficiently.
                </p>
                <br />

                <div className="mt-5">
                    <h3 className="text-center mb-4">Books in Store</h3>

                    {/* Search Input Field */}
                    <div className="mb-4">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by title, author, category, ISBN, or description..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            style={{ maxWidth: '600px', margin: '0 auto', display: 'block' }}
                        />
                    </div>

                    {loading && (
                        <div className="text-center text-secondary">Loading books...</div>
                    )}
                    {error && (
                        <div className="alert alert-danger text-center">{error}</div>
                    )}
                    {!loading && !error && (
                        <ul className="list-group">
                            {filteredBooks.length > 0 ? (
                                filteredBooks.map((book) => (
                                    <li
                                        key={book.bookid}
                                        className="list-group-item d-flex align-items-center justify-content-start my-2"
                                        style={{ boxShadow: "0 2px 5px rgba(0,0,0,0.1)", borderRadius: "8px" }}
                                    >
                                        <img
                                            src={book.imageData ? `data:image/jpeg;base64,${book.imageData}` : '/images/placeholder.jpg'}
                                            alt={book.title || 'Book Cover'}
                                            style={{
                                                width: '80px',
                                                minWidth: '80px',
                                                height: '100px',
                                                minHeight: '100px',
                                                objectFit: 'cover',
                                                marginRight: '20px',
                                                borderRadius: '5px',
                                                backgroundColor: '#f0f0f0'
                                            }}
                                            onError={(e) => {
                                                console.warn(`AdminDashboard: Image failed to load from Base64 for book ID ${book.bookid}. Falling back to static placeholder.`);
                                                e.target.onerror = null;
                                                e.target.src = '/images/placeholder.jpg';
                                            }}
                                        />
                                        <div style={{ flexGrow: 1 }}>
                                            <h5 className="mb-1"><strong>{book.title}</strong></h5>
                                            <p className="mb-1 text-muted">by {book.author ? book.author.name : 'Unknown Author'}</p>
                                            <p className="mb-1">Category: {book.category ? book.category.name : 'N/A'}</p>
                                            {book.isbn && <p className="mb-1">ISBN: {book.isbn}</p>}
                                            <p className="mb-1">Price: ${book.price ? book.price.toFixed(2) : 'N/A'}</p>
                                            <p className="mb-1">Stock Quantity: {book.stockquantity !== undefined ? book.stockquantity : 'N/A'}</p>
                                            {book.description && (
                                                <p className="mb-0 text-muted" style={{ fontSize: '0.85em', maxHeight: '3em', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                    Description: {book.description}
                                                </p>
                                            )}
                                        </div>
                                    </li>
                                ))
                            ) : (
                                <li className="list-group-item text-center">
                                    {searchTerm ? "No books match your search." : "No books found in the system."}
                                </li>
                            )}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
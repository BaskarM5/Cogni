import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// API endpoints
const API_INVENTORY_URL = "http://localhost:1021/api/inventory";
const API_BOOKS_URL = "http://localhost:1021/api/books";

const InventoryManagement = () => {
    const navigate = useNavigate();

    // State variables
    const [inventory, setInventory] = useState([]);
    const [books, setBooks] = useState([]);
    const [newEntry, setNewEntry] = useState({ bookId: "", quantity: "" });
    const [alertMessage, setAlertMessage] = useState(null);
    const [editingEntryId, setEditingEntryId] = useState(null); // Stores the ID of the entry being edited

    // Log initial state
    console.log("InventoryManagement: Initial Render");
    console.log("Initial States: editingEntryId:", editingEntryId, "newEntry:", newEntry);

    // Helper to get authentication token from local storage
    const getAuthToken = () => {
        const token = localStorage.getItem("jwtToken");
        console.log("getAuthToken: Retrieved token:", token ? "Exists" : "Null/Undefined");
        return token;
    };

    // Effect for fetching data on component mount
    useEffect(() => {
        console.log("InventoryManagement: useEffect triggered (component mounted or dependencies changed)");
        fetchInventory();
        fetchBooks();

        // Optional: Cleanup function if needed (e.g., for event listeners)
        return () => {
            console.log("InventoryManagement: Component unmounted.");
        };
    }, []); // Empty dependency array means this runs once on mount

    // Log state changes (optional, can be very chatty)
    useEffect(() => {
        console.log("State Change Detected: editingEntryId =", editingEntryId);
    }, [editingEntryId]);

    useEffect(() => {
        console.log("State Change Detected: newEntry =", newEntry);
    }, [newEntry]);


    // --- Data Fetching Functions ---

    const fetchInventory = async () => {
        console.log("fetchInventory: Attempting to fetch inventory...");
        try {
            const response = await fetch(`${API_INVENTORY_URL}/all`, {
                method: "GET",
                headers: { "Authorization": `Bearer ${getAuthToken()}`, "Content-Type": "application/json" }
            });

            if (!response.ok) {
                const errorData = await response.text();
                console.error(`fetchInventory: HTTP Error: ${response.status}`, errorData);
                throw new Error(`Error fetching inventory: ${response.status} - ${errorData}`);
            }

            const data = await response.json();
            console.log("fetchInventory: Successfully fetched inventory:", data);
            setInventory(data);
        } catch (error) {
            console.error("fetchInventory: Failed to fetch inventory due to error:", error);
            showAlert(`Failed to fetch inventory: ${error.message}`, "danger");
        }
    };

    const fetchBooks = async () => {
        console.log("fetchBooks: Attempting to fetch books...");
        try {
            const response = await fetch(`${API_BOOKS_URL}/all`, {
                method: "GET",
                headers: { "Authorization": `Bearer ${getAuthToken()}`, "Content-Type": "application/json" }
            });

            if (!response.ok) {
                const errorData = await response.text();
                console.error(`fetchBooks: HTTP Error: ${response.status}`, errorData);
                throw new Error(`Error fetching books: ${response.status} - ${errorData}`);
            }

            const data = await response.json();
            console.log("fetchBooks: Successfully fetched books:", data);
            setBooks(data);
        } catch (error) {
            console.error("fetchBooks: Failed to fetch books due to error:", error);
            showAlert(`Failed to fetch books: ${error.message}`, "danger");
        }
    };

    // --- UI Helper Functions ---

    const showAlert = (message, type = "success") => {
        console.log(`showAlert: Displaying alert - Type: ${type}, Message: ${message}`);
        setAlertMessage({ message, type });
        setTimeout(() => {
            console.log("showAlert: Clearing alert message.");
            setAlertMessage(null);
        }, 2000);
    };

    // --- Inventory Data Preparation ---

    const prepareInventoryData = () => {
        console.log("prepareInventoryData: Preparing data from newEntry:", newEntry);
        const bookId = parseInt(newEntry.bookId, 10);
        const quantity = parseInt(newEntry.quantity, 10);

        if (isNaN(bookId) || newEntry.bookId === "") {
            console.error("prepareInventoryData: Validation Error - Invalid Book ID or empty.");
            throw new Error("Please select a valid Book.");
        }
        if (isNaN(quantity) || quantity <= 0) {
            console.error("prepareInventoryData: Validation Error - Quantity must be a positive number.", newEntry.quantity);
            throw new Error("Quantity must be a positive number.");
        }

        const data = {
            book: { bookid: bookId },
            quantity: quantity
        };
        console.log("prepareInventoryData: Prepared data:", data);
        return data;
    };

    // --- CRUD Operations ---

    const addInventoryEntry = async () => {
        console.log("addInventoryEntry: Initiating add operation.");
        try {
            const entryData = prepareInventoryData();
            console.log("addInventoryEntry: Sending data for POST:", entryData);

            const response = await fetch(API_INVENTORY_URL, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(entryData),
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`addInventoryEntry: HTTP Error: ${response.status}`, errorText);
                throw new Error(`Failed to add inventory entry: ${errorText}`);
            }

            console.log("addInventoryEntry: Successfully added entry. Refreshing inventory...");
            fetchInventory(); // Refresh the list
            setNewEntry({ bookId: "", quantity: "" }); // Clear form
            showAlert("Inventory added successfully!");
        } catch (error) {
            console.error("addInventoryEntry: Error during add operation:", error);
            showAlert(`Error adding inventory: ${error.message}`, "danger");
        }
    };

    const updateInventoryEntry = async () => {
        console.log("updateInventoryEntry: Initiating update operation for ID:", editingEntryId);
        try {
            if (!editingEntryId) {
                console.warn("updateInventoryEntry: No editingEntryId found, aborting update.");
                showAlert("No inventory entry selected for update.", "warning");
                return;
            }

            const entryData = {
                // Include inventoryid as expected by the backend for PUT /update
                inventoryid: editingEntryId,
                book: { bookid: parseInt(newEntry.bookId, 10) }, // Ensure bookid is parsed as number
                quantity: parseInt(newEntry.quantity, 10) // Ensure quantity is parsed as number
            };
            console.log("updateInventoryEntry: Sending data for PUT:", entryData);

            // Corrected URL for PUT: /api/inventory/update
            const response = await fetch(`${API_INVENTORY_URL}/update`, {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(entryData),
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`updateInventoryEntry: HTTP Error: ${response.status}`, errorText);
                throw new Error(`Failed to update inventory entry: ${errorText}`);
            }

            console.log("updateInventoryEntry: Successfully updated entry. Refreshing inventory...");
            fetchInventory(); // Refresh the list
            setNewEntry({ bookId: "", quantity: "" }); // Clear form
            setEditingEntryId(null); // Exit editing mode
            showAlert("Inventory updated successfully!");
        } catch (error) {
            console.error("updateInventoryEntry: Error during update operation:", error);
            showAlert(`Error updating inventory: ${error.message}`, "danger");
        }
    };

    const deleteInventoryEntry = async (id) => {
        console.log("deleteInventoryEntry: Initiating delete operation for ID:", id);
        if (!window.confirm("Are you sure you want to delete this inventory entry?")) {
            console.log("deleteInventoryEntry: User cancelled deletion.");
            return; // User cancelled
        }
        try {
            // Corrected URL for DELETE: /api/inventory/delete/{id}
            const response = await fetch(`${API_INVENTORY_URL}/delete/${id}`, {
                method: "DELETE",
                headers: { "Authorization": `Bearer ${getAuthToken()}`, "Content-Type": "application/json" }
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`deleteInventoryEntry: HTTP Error: ${response.status}`, errorText);
                throw new Error(`Failed to delete inventory entry: ${errorText}`);
            }

            console.log(`deleteInventoryEntry: Successfully deleted entry with ID: ${id}. Refreshing inventory...`);
            fetchInventory(); // Refresh the list
            showAlert("Inventory entry deleted successfully!");
        } catch (error) {
            console.error("deleteInventoryEntry: Error during delete operation:", error);
            showAlert(`Error deleting inventory: ${error.message}`, "danger");
        }
    };

    // --- Form Handling ---

    const handleSubmitInventory = () => {
        console.log("handleSubmitInventory: Button clicked. Current editingEntryId before logic:", editingEntryId);
        try {
            if (editingEntryId) {
                console.log("handleSubmitInventory: Calling updateInventoryEntry for ID:", editingEntryId);
                updateInventoryEntry();
            } else {
                console.log("handleSubmitInventory: Calling addInventoryEntry.");
                addInventoryEntry();
            }
        } catch (error) {
            console.error("handleSubmitInventory: Input validation or form submission error:", error);
            showAlert(`Input Error: ${error.message}`, "warning"); // Show input validation errors
        }
    };

    const startEditingEntry = (entry) => {
        console.log("startEditingEntry: Edit button clicked for entry:", entry);
        // Crucially, convert numerical IDs and quantity to strings for controlled inputs
        setNewEntry({
            bookId: entry.book ? entry.book.bookid.toString() : "",
            quantity: entry.quantity.toString()
        });
        console.log("startEditingEntry: setNewEntry updated to:", {
            bookId: entry.book ? entry.book.bookid.toString() : "",
            quantity: entry.quantity.toString()
        });

        // Use 'inventoryid' from the fetched object as the ID for editing
        setEditingEntryId(entry.inventoryid);
        console.log("startEditingEntry: editingEntryId set to:", entry.inventoryid);
    };

    const cancelEditing = () => {
        console.log("cancelEditing: Cancelling edit mode.");
        setNewEntry({ bookId: "", quantity: "" });
        setEditingEntryId(null);
        showAlert("Edit cancelled.", "info");
    };

    // --- Render Component ---

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            {/* Sidebar */}
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}>
                <h3 className="text-center">Admin</h3>
                <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/admin-dashboard")}>Dashboard</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/book-management")}>Manage Books</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/author-management")}>Manage Authors</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/category-management")}>Manage Categories</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }} onClick={() => navigate("/inventory-management")}>Manage Inventory</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/orders-management")}>Manage Orders</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/user-management")}>Manage Users</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/")}>Logout</button>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Inventory</h2>

                {/* Alert Message Display */}
                {alertMessage && (
                    <div className={`alert alert-${alertMessage.type} text-center`}>
                        {alertMessage.message}
                    </div>
                )}

                {/* Add/Edit Form */}
                <div className="mb-3">
                    <select
                        className="form-control mb-2"
                        value={newEntry.bookId}
                        onChange={(e) => setNewEntry({ ...newEntry, bookId: e.target.value })}
                        disabled={!!editingEntryId} // Disable book selection during edit
                    >
                        <option value="">Select Book</option>
                        {books.map(book => (
                            <option key={book.bookid} value={book.bookid}>
                                {book.bookid} - {book.title}
                            </option>
                        ))}
                    </select>

                    <input
                        type="number"
                        placeholder="Quantity"
                        className="form-control mb-2"
                        value={newEntry.quantity}
                        onChange={(e) => setNewEntry({ ...newEntry, quantity: e.target.value })}
                        min="0" // Ensure non-negative quantities
                    />

                    <button className="btn btn-success" onClick={handleSubmitInventory}>
                        {editingEntryId ? "Update Inventory" : "Add Inventory"}
                    </button>
                    {editingEntryId && (
                        <button className="btn btn-secondary ms-2" onClick={cancelEditing}>Cancel Edit</button>
                    )}
                </div>

                {/* Inventory Table */}
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Inventory ID</th>
                            <th>Book ID</th>
                            <th>Book Title</th>
                            <th>Quantity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {inventory.length === 0 ? (
                            <tr>
                                <td colSpan="5" className="text-center">No inventory items found.</td>
                            </tr>
                        ) : (
                            inventory.map(entry => (
                                // Corrected: Use entry.inventoryid as the key
                                <tr key={entry.inventoryid}>
                                    <td>{entry.inventoryid}</td> {/* This line displays the Inventory ID */}
                                    <td>{entry.book ? entry.book.bookid : 'N/A'}</td>
                                    <td>{entry.book ? entry.book.title : 'N/A'}</td>
                                    <td>{entry.quantity}</td>
                                    <td>
                                        <button className="btn btn-warning btn-sm" onClick={() => startEditingEntry(entry)}>Edit</button>
                                        <button className="btn btn-danger btn-sm ms-2" onClick={() => deleteInventoryEntry(entry.inventoryid)}>Delete</button> {/* Use inventoryid for deletion */}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default InventoryManagement;
// components/books/BookCard.jsx

import React from "react";
import "../Styles/styles.css";

const BookCard = ({ book, onViewDetail }) => {
  return (
    <div className="book-card">
      {/* Display image from Base64 data */}
      {/* Fallback for cases where imageData might be missing or invalid Base64 */}
      <img
        src={book.imageData ? `data:image/jpeg;base64,${book.imageData}` : "https://placehold.co/150x200/cccccc/000000?text=No+Image"}
        alt={book.title}
        className="book-image"
      />
      <h3 className="book-title">{book.title}</h3>
      {/* Correctly access the author's name from the nested object */}
      <p className="book-author">by {book.author ? book.author.name : 'Unknown Author'}</p>
      <p className="book-price">${book.price ? book.price.toFixed(2) : 'N/A'}</p>
      <button className="details-button" onClick={() => onViewDetail(book)}>
        View Details
      </button>
    </div>
  );
};

export default BookCard;

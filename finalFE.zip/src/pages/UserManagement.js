import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:1021/api/users"; // Users API

const UserManagement = () => {
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [alertMessage, setAlertMessage] = useState(null);

    // Retrieve token
    const getAuthToken = () => localStorage.getItem("jwtToken");

    // Fetch users on component mount
    useEffect(() => {
        fetchUsers();
    }, []);
    

    const fetchUsers = async () => {
        const token = localStorage.getItem("jwtToken");
        if (!token) {
            console.error("Error: No JWT Token found.");
            return;
        }
    
        try {
            const response = await fetch("http://localhost:1021/api/users", {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                }
            });
    
            if (!response.ok) {
                throw new Error(`Error: ${response.status}`);
            }
    
            const data = await response.json();
            console.log("Fetched Users:", data); // ✅ Debug log
    
            // ✅ Ensure users are stored in state
            const filteredUsers = data.filter(user => user.role.toLowerCase() === "user");
            setUsers(filteredUsers);
            console.log("Updated users state:", filteredUsers); // ✅ Debug log after state update
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };
    
    

    const showAlert = (message) => {
        setAlertMessage(message);
        setTimeout(() => setAlertMessage(null), 2000);
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
        {/* Sidebar Navigation */}
        <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
            <h3 className="text-center">Admin</h3>
            
            <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/admin-dashboard")}>
                Dashboard
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/book-management")}>
                Manage Books
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/author-management")}>
                Manage Authors
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/category-management")}>
                Manage Categories
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/inventory-management")}>
                Manage Inventory
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
                onClick={() => navigate("/user-management")}>
                Manage Users
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/")}>
                Logout
            </button>
        </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Users</h2>

                {alertMessage && <div className="alert alert-success text-center">{alertMessage}</div>}

                {/* User List Table */}
                {users.length > 0 ? (
    <table className="table table-bordered">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            {users.map(user => (
                <tr key={user.id}>
                    <td>{user.id}</td>  
                    <td>{user.name}</td>  
                    <td>{user.email}</td>  
                </tr>
            ))}
        </tbody>
    </table>
) : (
    <p className="text-center">No users found.</p>
)}
</div>
        </div>
    );
};

export default UserManagement;

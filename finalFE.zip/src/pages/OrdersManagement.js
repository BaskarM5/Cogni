import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:1021/api/order"; // Orders API

const OrdersManagement = () => {
    const navigate = useNavigate();
    const [orders, setOrders] = useState([]);
    const [alertMessage, setAlertMessage] = useState(null);

    // Retrieve token
    const getAuthToken = () => localStorage.getItem("jwtToken");

    // Fetch orders on component mount
    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        const token = getAuthToken();
        if (!token) {
            console.error("Error: No JWT Token found.");
            return;
        }

        try {
            const response = await fetch(`${API_URL}/all`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                }
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.status}`);
            }

            const data = await response.json();
            console.log("Fetched Orders:", data);
            setOrders(data);
        } catch (error) {
            console.error("Error fetching orders:", error);
        }
    };

    const showAlert = (message) => {
        setAlertMessage(message);
        setTimeout(() => setAlertMessage(null), 2000);
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            {/* Sidebar Navigation */}
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
                <h3 className="text-center">Admin</h3>
                
                <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/admin-dashboard")}>
                    Dashboard
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/book-management")}>
                    Manage Books
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/author-management")}>
                    Manage Authors
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/category-management")}>
                    Manage Categories
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/inventory-management")}>
                    Manage Inventory
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/user-management")}>
                    Manage Users
                </button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/")}>
                    Logout
                </button>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Orders</h2>

                {alertMessage && <div className="alert alert-success text-center">{alertMessage}</div>}

                {/* Orders List Table */}
                {orders.length > 0 ? (
                    <table className="table table-bordered">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Order Date</th>
                                <th>Status</th>
                                <th>Total Amount</th>
                                <th>User ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            {orders.map(order => (
                                <tr key={order.orderid}>
                                    <td>{order.orderid}</td>  
                                    <td>{order.orderDate}</td>  
                                    <td>{order.status}</td>  
                                    <td>${order.totalAmount ? order.totalAmount.toFixed(2) : '0.00'}</td>
                                    <td>{order.user ? order.user.id : 'N/A'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p className="text-center">No orders found.</p>
                )}
            </div>
        </div>
    );
};

export default OrdersManagement;

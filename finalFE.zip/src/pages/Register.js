import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../Styles/Register.css";
const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "USER", // Default role selection
  });

  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); // Handles redirection

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    try {
      const response = await axios.post("http://localhost:1021/api/users", formData);
      console.log("Registration response:", response.data);

      // ✅ Ensure user role & email are stored correctly
      if (response.data?.role && response.data?.email) {
        localStorage.setItem("userRole", response.data.role);
        localStorage.setItem("userEmail", response.data.email);
      }

      // ✅ Display success message before redirect
      setMessage("Registration successful! Redirecting...");
      setTimeout(() => navigate("/login"), 1500);

    } catch (err) {
      console.error("Registration failed:", err);

      // ✅ Handle common errors including 403 Forbidden and 404 Not Found
      if (err.response?.status === 409) {
        setError("User already exists! Please use a different email.");
      } else if (err.response?.status === 403) {
        setError("Access forbidden! You may need admin privileges.");
      } else if (err.response?.status === 404) {
        setError("Server not found. Please check your API connection.");
      } else {
        setError(err.response?.data?.error || "Registration failed. Please try again.");
      }
    }
  };

  return (
    <div className="register-container">
      <div className="register-card">
        <h2>Register</h2>
        <br/>
        {message && <div className="alert-success">{message}</div>}
        {error && <div className="alert-danger">{error}</div>}
        <form onSubmit={handleSubmit}>
        <br/>
          <label>Name:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
          <br/>
          <label>Email:</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
          <br/>
          <label>Password:</label>
          <input type="password" name="password" value={formData.password} onChange={handleChange} required />
          <br/>
          <label>Role:</label>
          <div className="role-container">
    <div className="role-item">
        <input type="radio" name="role" value="USER" checked={formData.role === "USER"} onChange={handleChange} />
        <label>User</label>
    </div>

    <div className="role-item">
        <input type="radio" name="role" value="ADMIN" checked={formData.role === "ADMIN"} onChange={handleChange} />
        <label>Admin</label>
    </div>
</div>
<br/>
<br/>


          <button type="submit">Register</button>
          <div className="login-link">
          <span>Already have an account? </span>
          <span className="login-text" onClick={() => navigate("/login")}>Login</span>
        </div>
        
        </form>
      </div>
    </div>
);

};

export default Register;

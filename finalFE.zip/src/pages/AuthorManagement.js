import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const API_URL = "http://localhost:1021/api/authors"; // Your API endpoint

const AuthorManagement = () => {
    const navigate = useNavigate();
    const [authors, setAuthors] = useState([]);
    const [newAuthor, setNewAuthor] = useState({ name: "", biography: "" });
    const [alertMessage, setAlertMessage] = useState(null);
    const [editingAuthorId, setEditingAuthorId] = useState(null); // Track which author is being edited

    // Retrieve token
    const getAuthToken = () => localStorage.getItem("jwtToken");

    // Fetch all authors on component mount
    useEffect(() => {
        fetchAuthors();
    }, []);

    const fetchAuthors = async () => {
        try {
            const response = await fetch(API_URL, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                }
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.status}`);
            }

            const data = await response.json();
            setAuthors(data);
        } catch (error) {
            console.error("Error fetching authors:", error);
        }
    };

    const showAlert = (message) => {
        setAlertMessage(message);
        setTimeout(() => setAlertMessage(null), 2000); // Alert disappears after 2 seconds
    };

    const addOrUpdateAuthor = async () => {
        try {
            const method = editingAuthorId ? "PUT" : "POST";
            const url = editingAuthorId ? `${API_URL}/${editingAuthorId}` : API_URL;

            const response = await fetch(url, {
                method,
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(newAuthor),
            });

            if (response.ok) {
                fetchAuthors();
                setNewAuthor({ name: "", biography: "" });
                setEditingAuthorId(null);
                showAlert(editingAuthorId ? "Author updated successfully!" : "Author added successfully!");
            }
        } catch (error) {
            console.error("Error saving author:", error);
        }
    };

    const startEditingAuthor = (author) => {
        setNewAuthor({ name: author.name, biography: author.biography });
        setEditingAuthorId(author.id);
    };

    const deleteAuthor = async (id) => {
        try {
            await fetch(`${API_URL}/${id}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                }
            });

            fetchAuthors();
            showAlert("Author deleted successfully!");
        } catch (error) {
            console.error("Error deleting author:", error);
        }
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
        {/* Sidebar Navigation */}
        <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
            <h3 className="text-center">Admin</h3>
            
            <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/admin-dashboard")}>
                Dashboard
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/book-management")}>
                Manage Books
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
                onClick={() => navigate("/author-management")}>
                Manage Authors
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/category-management")}>
                Manage Categories
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/inventory-management")}>
                Manage Inventory
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                    onClick={() => navigate("/orders-management")}>
                    Manage Orders
                </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/user-management")}>
                Manage Users
            </button>
            <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
                onClick={() => navigate("/")}>
                Logout
            </button>
        </div>

            {/* Main Content */}
            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Authors</h2>
<br/>
                {alertMessage && (
                    <div className="alert alert-success text-center">{alertMessage}</div>
                )}
<br/>
                {/* Add/Edit Author Form */}
                <div className="mb-3">
                    <input type="text" placeholder="Author Name" className="form-control mb-2"
                        value={newAuthor.name} onChange={(e) => setNewAuthor({ ...newAuthor, name: e.target.value })} />
                    <br/>
                    <textarea placeholder="Biography" className="form-control mb-2"
                        value={newAuthor.biography} onChange={(e) => setNewAuthor({ ...newAuthor, biography: e.target.value })} />
                    <br/>
                    <button className="btn btn-success" onClick={addOrUpdateAuthor}>
                        {editingAuthorId ? "Update Author" : "Add Author"}
                    </button>
                </div>
                <br/>
                <br/>
                {/* Author Table */}
                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Author ID</th>
                            <th>Author Name</th>
                            <th>Biography</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {authors.map(author => (
                            <tr key={author.id}>
                                <td>{author.id}</td>
                                <td>{author.name}</td>
                                <td>{author.biography}</td>
                                <td>
                                    <button className="btn btn-warning" onClick={() => startEditingAuthor(author)}>Edit</button>
                                    <br/>
                                    <br/>
                                    <button className="btn btn-danger" onClick={() => deleteAuthor(author.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AuthorManagement;

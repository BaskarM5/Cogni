import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const API_BASE_URL = "http://localhost:1021/api/books"; // Base URL for books
const AUTHOR_API_URL = "http://localhost:1021/api/authors";
const CATEGORY_API_URL = "http://localhost:1021/api/categories";

const BookManagement = () => {
    const navigate = useNavigate();
    const [books, setBooks] = useState([]);
    const [authors, setAuthors] = useState([]);
    const [categories, setCategories] = useState([]);
    const [newBook, setNewBook] = useState({
        title: "",
        description: "",
        price: "",
        stockQuantity: "",
        version: "",
        authorId: "",
        categoryId: "",
        imageData: ""
    });
    const [alertMessage, setAlertMessage] = useState(null);
    const [editingBookId, setEditingBookId] = useState(null);

    const getAuthToken = () => localStorage.getItem("jwtToken");

    useEffect(() => {
        fetchBooks();
        fetchAuthors();
        fetchCategories();
    }, []);

    const fetchBooks = async () => {
        try {
            // Updated to use API_BASE_URL + "/all" for fetching all books
            const response = await fetch(`${API_BASE_URL}/all`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                },
            });
            if (!response.ok) throw new Error(`Error: ${response.status}`);
            const data = await response.json();
            setBooks(data);
        } catch (error) {
            console.error("Error fetching books:", error);
        }
    };

    const fetchAuthors = async () => {
        try {
            const response = await fetch(AUTHOR_API_URL, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                },
            });
            if (!response.ok) throw new Error(`Error: ${response.status}`);
            setAuthors(await response.json());
        } catch (error) {
            console.error("Error fetching authors:", error);
        }
    };

    const fetchCategories = async () => {
        try {
            const response = await fetch(CATEGORY_API_URL, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                },
            });
            if (!response.ok) throw new Error(`Error: ${response.status}`);
            setCategories(await response.json());
        } catch (error) {
            console.error("Error fetching categories:", error);
        }
    };

    const showAlert = (message) => {
        setAlertMessage(message);
        setTimeout(() => setAlertMessage(null), 2000);
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64Data = reader.result.split(",")[1]; // remove data:image/png;base64,
                setNewBook((prev) => ({ ...prev, imageData: base64Data }));
            };
            reader.readAsDataURL(file);
        }
    };

    // --- NEW FUNCTIONS ---

    const prepareBookData = () => {
        return {
            title: newBook.title,
            description: newBook.description,
            price: parseFloat(newBook.price),
            stockquantity: parseInt(newBook.stockQuantity),
            version: parseInt(newBook.version),
            imageData: newBook.imageData,
            author: { id: parseInt(newBook.authorId) },
            category: { id: parseInt(newBook.categoryId) }
        };
    };

    const addBook = async () => {
        try {
            const bookData = prepareBookData();
            console.log("Adding book:", bookData);

            const response = await fetch(API_BASE_URL, { // POST to /api/books
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(bookData),
            });

            if (!response.ok) {
                console.error("Error adding book:", await response.text());
                throw new Error("Failed to add book.");
            }

            fetchBooks(); // Refresh the book list
            setNewBook({ title: "", description: "", price: "", stockQuantity: "", version: "", authorId: "", categoryId: "", imageData: "" }); // Clear form
            showAlert("Book added successfully!");
        } catch (error) {
            console.error("Error adding book:", error);
            showAlert(`Error adding book: ${error.message}`);
        }
    };

    const updateBook = async () => {
        try {
            if (!editingBookId) {
                console.error("No book selected for editing.");
                return;
            }

            const bookData = prepareBookData();
            console.log(`Updating book ${editingBookId}:`, bookData);

            const response = await fetch(`${API_BASE_URL}/${editingBookId}`, { // PUT to /api/books/{id}
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(bookData),
            });

            if (!response.ok) {
                console.error("Error updating book:", await response.text());
                throw new Error("Failed to update book.");
            }

            fetchBooks(); // Refresh the book list
            setNewBook({ title: "", description: "", price: "", stockQuantity: "", version: "", authorId: "", categoryId: "", imageData: "" }); // Clear form
            setEditingBookId(null); // Exit editing mode
            showAlert("Book updated successfully!");
        } catch (error) {
            console.error("Error updating book:", error);
            showAlert(`Error updating book: ${error.message}`);
        }
    };

    // Replace the combined addOrUpdateBook with this handler
    const handleSubmitBook = () => {
        if (editingBookId) {
            updateBook();
        } else {
            addBook();
        }
    };

    const handleEditClick = (book) => {
        setEditingBookId(book.bookid);
        setNewBook({
            title: book.title,
            description: book.description,
            price: book.price,
            stockQuantity: book.stockquantity,
            version: book.version,
            authorId: book.author ? book.author.id : "",
            categoryId: book.category ? book.category.id : "",
            imageData: book.imageData || "" // Retain existing image data if available
        });
    };

    // --- END NEW FUNCTIONS ---

    const deleteBook = async (id) => {
        try {
            // Updated to use API_BASE_URL directly
            await fetch(`${API_BASE_URL}/${id}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${getAuthToken()}`,
                    "Content-Type": "application/json"
                },
            });

            fetchBooks();
            showAlert("Book deleted successfully!");
        } catch (error) {
            console.error("Error deleting book:", error);
        }
    };

    return (
        <div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
            <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}>
                <h3 className="text-center">Admin</h3>
                <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/admin-dashboard")}>Dashboard</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }} onClick={() => navigate("/book-management")}>Manage Books</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/author-management")}>Manage Authors</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/category-management")}>Manage Categories</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/inventory-management")}>Manage Inventory</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/orders-management")}>Manage Orders</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/user-management")}>Manage Users</button>
                <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }} onClick={() => navigate("/")}>Logout</button>
            </div>

            <div className="flex-grow-1 p-5 text-black" style={{ backgroundColor: "#D4D0D5" }}>
                <h2 className="text-center">Manage Books</h2>
                {alertMessage && <div className="alert alert-success text-center">{alertMessage}</div>}

                <div className="mb-3">
                    <input type="text" placeholder="Book Title" className="form-control mb-2" value={newBook.title} onChange={(e) => setNewBook({ ...newBook, title: e.target.value })} />
                    <textarea placeholder="Description" className="form-control mb-2" value={newBook.description} onChange={(e) => setNewBook({ ...newBook, description: e.target.value })} />
                    <input type="number" placeholder="Price" className="form-control mb-2" value={newBook.price} onChange={(e) => setNewBook({ ...newBook, price: e.target.value })} />
                    <input type="number" placeholder="Stock Quantity" className="form-control mb-2" value={newBook.stockQuantity} onChange={(e) => setNewBook({ ...newBook, stockQuantity: e.target.value })} />
                    <input type="text" placeholder="Version" className="form-control mb-2" value={newBook.version} onChange={(e) => setNewBook({ ...newBook, version: e.target.value })} />

                    <select className="form-control mb-2" value={newBook.authorId} onChange={(e) => setNewBook({ ...newBook, authorId: e.target.value })}>
                        <option value="">Select Author ID</option>
                        {authors.map(author => <option key={author.id} value={author.id}>{author.name}</option>)} {/* Changed to show author name */}
                    </select>

                    <select className="form-control mb-2" value={newBook.categoryId} onChange={(e) => setNewBook({ ...newBook, categoryId: e.target.value })}>
                        <option value="">Select Category ID</option>
                        {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)} {/* Changed to show category name */}
                    </select>

                    {/* Image Upload Input */}
                    <input type="file" accept="image/*" className="form-control mb-3" onChange={handleImageUpload} />

                    <button className="btn btn-success" onClick={handleSubmitBook}>
                        {editingBookId ? "Update Book" : "Add Book"}
                    </button>
                    {editingBookId && (
                        <button className="btn btn-secondary ms-2" onClick={() => {
                            setEditingBookId(null);
                            setNewBook({ title: "", description: "", price: "", stockQuantity: "", version: "", authorId: "", categoryId: "", imageData: "" });
                        }}>
                            Cancel Edit
                        </button>
                    )}
                </div>

                <table className="table table-bordered">
                    <thead>
                        <tr>
                            <th>Book ID</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {books.map(book => (
                            <tr key={book.bookid}>
                                <td>{book.bookid}</td>
                                <td>{book.title}</td>
                                <td>{book.author ? book.author.name : 'N/A'}</td>
                                <td>{book.category ? book.category.name : 'N/A'}</td>
                                <td>
                                    <button className="btn btn-primary btn-sm me-2" onClick={() => handleEditClick(book)}>Edit</button>
                                    <button className="btn btn-danger btn-sm" onClick={() => deleteBook(book.bookid)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default BookManagement;
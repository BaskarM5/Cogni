// pages/Dashboard.jsx

import BookCard from '../components/books/BookCard';
import Cart from '../components/cart/Cart';
import '../styles.css';

const books = [
  { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price: 10.99, thumbnail: 'https://covers.openlibrary.org/b/id/7222246-L.jpg' },
  { id: 2, title: 'To Kill a Mickingbiad', author: 'Hueber Cortell', price: 12.50, thumbnail: 'https://covers.openlibrary.org/b/id/8228691-L.jpg' },
  { id: 3, title: '1984', author: 'E. Gourt Voergald', price: 9.99, thumbnail: 'https://covers.openlibrary.org/b/id/153541-L.jpg' },
  { id: 4, title: 'Pride and Prejudice', author: 'Annie Orenston', price: 8.95, thumbnail: 'https://covers.openlibrary.org/b/id/174118-L.jpg' }
];

const cartItems = [
  { id: 1, title: 'The Great Gatsby', quantity: 2, price: 10.99 },
  { id: 2, title: 'Aus Steve Woods', quantity: 2, price: 10.99 }
];

export default function Dashboard() {
  return (
    <div className="dashboard">
      {/* <h3 className="section-title">Your Cart</h3>
      <Cart items={cartItems} />
      <h3 className="section-title">Browse Books</h3> */}
      <div className="book-grid">
        {/* {books.map(book => <BookCard key={book.id} book={book} books={books} />)} */}
        <BookCard books={books} />
      </div>
    </div>
  );
}
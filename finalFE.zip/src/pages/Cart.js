import React, { useContext, useState } from "react";
import { CartContext } from "./CartContext";
import "../Styles/Cart.css";// Ensure your Cart.css is correctly linked and provides necessary styling
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons"; // ✅ Import trash icon
import { useNavigate } from "react-router-dom";
const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, clearCart } = useContext(CartContext);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [checkoutMessage, setCheckoutMessage] = useState(null); // For success/error messages
  const [paymentError, setPaymentError] = useState(null); // For errors in payment modal
  const navigate = useNavigate();
  // Calculate total price of items in the cart
  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // Function to open the payment modal
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      setCheckoutMessage({ type: 'error', text: "Your cart is empty. Please add items before checking out." });
      return;
    }
    setPaymentError(null); // Clear any previous payment errors
    setShowPaymentModal(true);
  };

  // Function to close the payment modal
  const handleClosePaymentModal = () => {
    setShowPaymentModal(false);
    setPaymentError(null); // Clear errors when closing
  };

  // Function to simulate payment and place order
  const handleProcessPayment = async (paymentDetails) => {
    setPaymentError(null); // Clear previous errors
    setCheckoutMessage(null); // Clear main checkout messages

    // Retrieve token and user email (userId for order creation) from localStorage
    const token = localStorage.getItem('jwtToken');
    const userEmail = localStorage.getItem('userEmail'); // Assuming email is stored as user ID for backend

    if (!token || !userEmail) {
      setPaymentError("Authentication details missing. Please log in again.");
      return;
    }

    // Construct the order object payload
    const orderPayload = {
      user: { // This needs to be a nested object to match backend's User relationship
        email: userEmail
      },
      orderDate: new Date().toISOString().split('T')[0], // Format to "YYYY-MM-DD" for LocalDate
      totalAmount: totalPrice, // This will be recalculated by the backend, but sending it is fine
      status: "PLACED", // Initial status of the order
      orderItems: cartItems.map(item => ({
        bookId: item.bookid,
        quantity: item.quantity,
        priceAtOrder: item.price // Store price at the time of order for historical accuracy
      }))
    };

    try {
      // Corrected backend endpoint to match OrderController's mapping: /order/save
      const response = await fetch("http://localhost:1021/api/order", { // Changed to /order/save
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(orderPayload)
      });

      if (!response.ok) {
        let errorMessage = `HTTP error! Status: ${response.status}.`;
        // Read response body as text first, then try to parse as JSON
        const errorBody = await response.text(); 
        try {
          const errorJson = JSON.parse(errorBody); // Attempt to parse the text as JSON
          errorMessage = errorJson.message || errorJson.error || errorBody; // Use specific fields or raw text
        } catch (jsonParseError) {
          errorMessage = errorBody; // If JSON parsing fails, use the raw text
        }
        
        console.error(`Order placement failed: ${errorMessage}`);
        setPaymentError(`Order failed: ${response.status} - ${errorMessage}`);

        // Specific handling for 401 Unauthorized or 403 Forbidden
        if (response.status === 401 || response.status === 403) {
          setPaymentError("Authentication failed or forbidden access. Please log in again with proper roles.");
          // Clear token and user info, then redirect to login (if navigate is available in this context)
          localStorage.removeItem('jwtToken');
          localStorage.removeItem('userRole');
          localStorage.removeItem('userEmail');
          // If you have `useNavigate` available here, you might redirect:
          // setTimeout(() => navigate("/login"), 1500); 
        }
        return;
      }

      // FIX: Changed response.json() to response.text() for successful responses
      // since the backend returns a String like "Order saved successfully!".
      const responseMessage = await response.text(); 
      setCheckoutMessage({ type: 'success', text: responseMessage + " Thank you for your purchase!" }); // Use backend message
      clearCart(); // Clear the cart after successful order
      handleClosePaymentModal(); // Close modal
      console.log("Order placed:", responseMessage);

    } catch (error) {
      console.error("Error processing payment/order:", error);
      setPaymentError("An unexpected error occurred during payment processing. Please try again.");
    }
  };

  return (
<div className="d-flex" style={{ minHeight: "100vh", height: "100%" }}>
      {/* Sidebar Navigation */}
      <div style={{ backgroundColor: "#2D093F", width: "300px", padding: "20px", color: "white", minHeight: "100vh" }}> 
          <h3 className="text-center">User</h3>
          
          <button className="btn w-100 mt-5" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/customer-dashboard")}>
              Home
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#4A0F67", color: "white" }}
              onClick={() => navigate("/cart")}>
              Cart
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/orders")}>
              Orders
          </button>
          <button className="btn w-100 mt-4" style={{ backgroundColor: "#2D093F", color: "white" }}
              onClick={() => navigate("/")}>
              Logout
          </button>
      </div>

      {/* Main Cart Content */}
      <div className="cart-container">
        <h2>Your Cart</h2>
        {checkoutMessage && <div className={`message ${checkoutMessage.type}`}>{checkoutMessage.text}</div>}
        {cartItems.length === 0 ? (
          <p className="empty-cart">Your cart is empty.</p>
        ) : (
          <>
            {cartItems.map((item) => (
              <div key={item.bookid} className="cart-item">
                <img src={item.imageData || "https://placehold.co/80x100"} alt={item.title} className="cart-image" />
                <div className="cart-details">
                  <h3>{item.title}</h3>
                  <p>Author: {item.author?.name || "Unknown Author"}</p>
                  <p>Price: ${item.price?.toFixed(2) || "N/A"}</p>
                  <div className="quantity-controls">
                    <button onClick={() => updateQuantity(item.bookid, item.quantity - 1)}>-</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.bookid, item.quantity + 1)}>+</button>
                    <br/>
                    <br/>
                    <br/>
                    <button className="remove-btn" onClick={() => removeFromCart(item.bookid)}>
                    <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            <div className="cart-summary">
              <h3>Total: ${totalPrice.toFixed(2)}</h3>
              <button className="checkout-btn" onClick={handleCheckout}>Checkout</button>
            </div>
          </>
        )}
      </div>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button className="modal-close" onClick={handleClosePaymentModal}>×</button>
            <br></br>
            <br/>

            <h3 style={{color:"#FFFFFF"}}>Dummy Payment Gateway</h3>
            {paymentError && <p className="error-text">{paymentError}</p>}
            <p style={{color:"#FFFFFF"}}>Total Amount: <span className="font-bold">${totalPrice.toFixed(2)}</span></p>

            {/* Payment Form Fields */}
            <div className="payment-form" >
              <label style={{color:"#FFFFFF"}}>Card Number:</label>
              <input type="text" placeholder="**** **** **** ****" defaultValue="1111222233334444" />
              
              <div className="split-fields">
                <div>
                  <label style={{color:"#FFFFFF"}}>Expiry (MM/YY):</label>
                  <input type="text" placeholder="MM/YY" defaultValue="12/25" />
                </div>
                <div>
                  <label style={{color:"#FFFFFF"}}>CVC:</label>
                  <input type="text" placeholder="***" defaultValue="123" />
                </div>
              </div>
              <br/>
              <button className="pay-btn" onClick={() => handleProcessPayment()}>Pay Now</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import AuthorManagement from "./pages/AuthorManagement";
import BookManagement from "./pages/BookManagement";
import InventoryManagement from "./pages/InventoryManagement";
import CategoryManagement from "./pages/CategoryManagement";
import UserManagement from"./pages/UserManagement";
import OrdersManagement from "./pages/OrdersManagement";
import CustomerDashboard from "./pages/CustomerDashboard";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/author-management" element={<AuthorManagement />} />
        <Route path="/book-management" element={<BookManagement />} />
        <Route path="/category-management" element={<CategoryManagement />} /> 
        <Route path="/orders-management" element={<OrdersManagement />} /> 
        <Route path="/user-management" element={<UserManagement />} /> 
        <Route path="/inventory-management" element={<InventoryManagement />} />
        <Route path="/customer-dashboard" element={<CustomerDashboard />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/orders" element={<Orders />} /> 
      </Routes>
    </Router>
  );
};

export default App;
package com.example.demo.service;

import java.util.List;
import com.example.demo.model.User;

public interface UserService {

    // Save a new user
    String saveUser(User user);

    // Update an existing user
    User updateUser(User user);

    // Get a user by ID
    User getUserById(Long userid);

    // Delete a user by ID
    String deleteUserById(Long userid);

    // Get all users
    List<User> getAllUsers();
}

package com.example.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Order;
import com.example.demo.model.User; // Assuming User entity is also in model package

public interface OrderRepository extends JpaRepository<Order, Long> {

    // Find orders by user correctly referencing the User entity's ID
    List<Order> findByUser_Id(Long userId); // Assuming User entity has getId() for primary key

    // Find orders by user and status using correct entity reference
    List<Order> findByUser_IdAndStatus(Long userId, String status);
}

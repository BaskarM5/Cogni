package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Transient; // Crucial import for @Transient

import com.fasterxml.jackson.annotation.JsonBackReference; // Import JsonBackReference

@Entity
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int quantity;

    // This field stores the price of the book at the time the order was placed.
    // Important for historical financial records, as book prices can change.
    private double priceAtOrder; 

    // This is the actual JPA relationship to the Book entity.
    // Hibernate will manage this as the foreign key column 'book_id'.
    @ManyToOne
    @JoinColumn(name = "book_id") // Foreign key column in OrderItem table linking to Book
    private Book book; // Reference to the Book entity

    // This field is used for receiving the bookId from the frontend JSON payload.
    // It's marked @Transient, meaning JPA will *not* try to map it to a database column.
    // It's a temporary holder for the ID that the service layer will use to fetch the actual Book entity.
    @Transient 
    private Long bookId; // Matches the 'bookId' property sent from the frontend (Cart.js)

    // This is the actual JPA relationship to the parent Order entity.
    // @JsonBackReference indicates this is the "back" side of the bidirectional relationship.
    // When an OrderItem is serialized, the 'order' reference will be ignored to prevent circular loops.
    @ManyToOne
    @JoinColumn(name = "order_id") // Foreign key column in OrderItem table linking to Order
    @JsonBackReference // This side will NOT be serialized
    private Order order; // Reference to the parent Order entity

    // Default Constructor (required by JPA)
    public OrderItem() {
    }

    // Parameterized Constructor (useful for constructing objects programmatically on the backend)
    public OrderItem(Long id, int quantity, double priceAtOrder, Book book, Order order) {
        this.id = id;
        this.quantity = quantity;
        this.priceAtOrder = priceAtOrder;
        this.book = book;
        this.order = order;
    }
    
    // IMPORTANT: Constructor for deserialization from frontend JSON.
    // Jackson will use this constructor or setters to populate fields from the incoming payload.
    // The 'bookId' will be populated here directly from the JSON.
    public OrderItem(int quantity, double priceAtOrder, Long bookId) {
        this.quantity = quantity;
        this.priceAtOrder = priceAtOrder;
        this.bookId = bookId; // This transient field gets the value from the frontend
    }

    // Getters and Setters for all fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPriceAtOrder() {
        return priceAtOrder;
    }

    public void setPriceAtOrder(double priceAtOrder) {
        this.priceAtOrder = priceAtOrder;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    // Getter for the transient bookId field (used by OrderServiceImpl to fetch Book)
    public Long getBookId() {
        return bookId;
    }

    // Setter for the transient bookId field (used by Jackson during JSON deserialization)
    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    @Override
    public String toString() {
        return "OrderItem{" +
               "id=" + id +
               ", quantity=" + quantity +
               ", priceAtOrder=" + priceAtOrder +
               ", bookId (transient)=" + bookId + 
               ", book=" + (book != null ? book.getBookid() : "null") + 
               ", orderId=" + (order != null ? order.getOrderid() : "null") + 
               '}';
    }
}

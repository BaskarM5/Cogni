package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.time.LocalDate; // Import LocalDate

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.demo.model.Order;
import com.example.demo.model.OrderItem;
import com.example.demo.model.Book;
import com.example.demo.model.User; // Import User model
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.UserRepository; // Autowire UserRepository
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.exception.BookNotFoundException;
import com.example.demo.exception.InsufficientStockException;
import com.example.demo.exception.UserNotFoundException; // For when user is not found

@Service
public class OrderServiceImpl implements OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderRepository repository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository; // Autowire UserRepository

    @Override
    @Transactional
    public String saveOrder(Order order) {
        if (order == null || order.getOrderItems() == null || order.getOrderItems().isEmpty()) {
            logger.warn("Attempted to save an invalid order or an order without items.");
            throw new IllegalArgumentException("Invalid order details or no items in order.");
        }

        // 1. Fetch and set the User entity based on the email provided in the payload
        // The frontend sends userEmail, which populates a dummy User object's email field.
        // We need to fetch the managed User entity from the database.
        if (order.getUser() == null || order.getUser().getEmail() == null) {
            throw new IllegalArgumentException("User email is required for order creation.");
        }
        User user = userRepository.findByEmail(order.getUser().getEmail()) // Assuming findByEmail exists in UserRepository
                         .orElseThrow(() -> new UserNotFoundException("User not found with email: " + order.getUser().getEmail()));
        order.setUser(user); // Set the managed User entity on the order

        // Ensure orderDate is set, default to today if not provided by frontend
        if (order.getOrderDate() == null) {
            order.setOrderDate(LocalDate.now());
        }

        // Initialize totalAmount to recalculate based on current book prices and quantities
        double calculatedTotalAmount = 0.0;

        // 2. Process each OrderItem to deduct stock and link to the managed Book entity
        for (OrderItem item : order.getOrderItems()) {
            // Use item.getBookId() (the transient field from the frontend payload)
            // Then fetch the actual, managed Book entity from the database
            Book book = bookRepository.findById(item.getBookId()) // Use getBookId() here to get the ID
                    .orElseThrow(() -> {
                        logger.error("Book not found for order item with ID: {}", item.getBookId());
                        return new BookNotFoundException("Book not found for order item with ID: " + item.getBookId());
                    });

            // Check for sufficient stock
            if (book.getStockquantity() < item.getQuantity()) {
                logger.error("Insufficient stock for book: {}. Available: {}, Requested: {}", book.getTitle(), book.getStockquantity(), item.getQuantity());
                throw new InsufficientStockException("Insufficient stock for book: " + book.getTitle() + ". Available: " + book.getStockquantity() + ", Requested: " + item.getQuantity());
            }

            // Deduct stock quantity
            book.setStockquantity(book.getStockquantity() - item.getQuantity());
            bookRepository.save(book); // Save the updated book with reduced stock

            // Set the managed Book entity on the OrderItem. This links OrderItem to Book in JPA.
            item.setBook(book); 
            // Link the OrderItem back to the parent Order. This is crucial for bidirectional relationship.
            item.setOrder(order); 

            // Use the current book's price for priceAtOrder, or ensure it's set if frontend didn't provide it
            if (item.getPriceAtOrder() == 0.0) { // Or if (item.getPriceAtOrder() == null)
                item.setPriceAtOrder(book.getPrice());
            }
            // Add to the calculated total amount
            calculatedTotalAmount += item.getPriceAtOrder() * item.getQuantity();
        }
        
        // Set the final calculated total amount on the order, overriding any frontend value
        order.setTotalAmount(calculatedTotalAmount);

        // 3. Save the Order. Due to CascadeType.ALL on orderItems, all linked OrderItems will also be saved.
        repository.save(order);
        logger.info("Order saved successfully with ID: {}", order.getOrderid());
        return "Order saved successfully!";
    }

    @Override
    public Order updateOrder(Order order) {
        return repository.findById(order.getOrderid())
                .map(existingOrder -> {
                    // Update User association if provided (requires fetching managed User)
                    if (order.getUser() != null && order.getUser().getEmail() != null) {
                        User user = userRepository.findByEmail(order.getUser().getEmail())
                                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + order.getUser().getEmail()));
                        existingOrder.setUser(user);
                    }
                    
                    existingOrder.setOrderDate(order.getOrderDate() != null ? order.getOrderDate() : existingOrder.getOrderDate());
                    existingOrder.setTotalAmount(order.getTotalAmount() > 0 ? order.getTotalAmount() : existingOrder.getTotalAmount());
                    existingOrder.setStatus(order.getStatus() != null && !order.getStatus().isEmpty() ? order.getStatus() : existingOrder.getStatus());
                    
                    // Logic for updating order items is more complex and depends on requirements:
                    // If order items are provided in update, you'd need to compare them with existing
                    // and adjust stock quantities for changes (e.g., increased quantity, removed item).
                    // For simplicity, this update method primarily updates scalar order fields.
                    
                    logger.info("Order updated successfully with ID: {}", order.getOrderid());
                    return repository.save(existingOrder);
                }).orElseThrow(() -> {
                    logger.error("Order not found for update with ID: {}", order.getOrderid());
                    return new OrderNotFoundException("Order not found with ID: " + order.getOrderid());
                });
    }


    @Override
    public Order getOrderById(Long orderid) {
        return repository.findById(orderid)
                .orElseThrow(() -> {
                    logger.error("Order not found with ID: {}", orderid);
                    return new OrderNotFoundException("Order not found with ID: " + orderid);
                });
    }

    @Override
    @Transactional
    public String deleteOrderById(Long orderid) {
        Optional<Order> optionalOrder = repository.findById(orderid);
        if (!optionalOrder.isPresent()) {
            logger.warn("Attempted to delete non-existent order with ID: {}", orderid);
            throw new OrderNotFoundException("Order not found for deletion with ID: " + orderid);
        }

        Order orderToDelete = optionalOrder.get();

        // Replenish stock for each item in the deleted order
        // Ensure orderItems are loaded if lazy-loaded. In a real scenario, consider fetching them explicitly
        // or ensure your JPA configuration handles this EAGERLY for deletion path.
        if (orderToDelete.getOrderItems() != null) {
            for (OrderItem item : orderToDelete.getOrderItems()) {
                Book book = item.getBook();
                if (book != null) {
                    book.setStockquantity(book.getStockquantity() + item.getQuantity());
                    bookRepository.save(book); // Save the updated book with replenished stock
                    logger.info("Replenished stock for book ID: {} by quantity: {}", book.getBookid(), item.getQuantity());
                } else {
                    logger.warn("Book reference is null for OrderItem ID: {} in order ID: {}", item.getId(), orderToDelete.getOrderid());
                }
            }
        } else {
            logger.warn("Order items list is null for order ID: {}. Cannot replenish stock.", orderToDelete.getOrderid());
        }

        repository.delete(orderToDelete);
        logger.info("Order deleted successfully with ID: {}", orderid);
        return "Order deleted successfully!";
    }
    
    

    @Override
    public List<Order> getAllOrders() {
        List<Order> orders = repository.findAll();
        // It's generally better to return an empty list than throw an exception for 'no orders found'
        // for GET /all endpoints, but if API design mandates an exception, keep it.
        // For RESTful APIs, 200 OK with an empty array is standard for no results.
        if (orders.isEmpty()) {
             logger.info("No orders found in the system. Returning empty list.");
        }
        return orders;
    }

    @Override
    public Order patchUpdateOrder(Long orderid, Order updatedFields) {
        return repository.findById(orderid).map(existingOrder -> {
            // Apply only provided fields (no stock changes handled here, only order details)
            if (updatedFields.getUser() != null && updatedFields.getUser().getEmail() != null) {
                User user = userRepository.findByEmail(updatedFields.getUser().getEmail())
                        .orElseThrow(() -> new UserNotFoundException("User not found with email: " + updatedFields.getUser().getEmail()));
                existingOrder.setUser(user);
            }
            if (updatedFields.getTotalAmount() > 0) { // Check for meaningful update
                existingOrder.setTotalAmount(updatedFields.getTotalAmount());
            }
            if (updatedFields.getStatus() != null && !updatedFields.getStatus().isEmpty()) {
                existingOrder.setStatus(updatedFields.getStatus());
            }
            if (updatedFields.getOrderDate() != null) {
                existingOrder.setOrderDate(updatedFields.getOrderDate());
            }
            // Note: If orderItems are part of the patch, more complex stock adjustment logic is needed.

            logger.info("Order partially updated with ID: {}", orderid);
            return repository.save(existingOrder);
        }).orElseThrow(() -> {
            logger.warn("Order not found for patch update with ID: {}", orderid);
            return new OrderNotFoundException("Order not found with ID: " + orderid);
        });
        
        
    }

	@Override
	public List<Order> getOrdersByUserEmail(String userEmail) {
		User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + userEmail));

			List<Order> orders = repository.findByUser_Id(user.getId());
			
			// If orderItems are lazy-loaded, you might need to trigger their loading
			// by accessing them, or configure FetchType.EAGER if appropriate for your use case.
			// For example:
			orders.forEach(order -> {
			   if (order.getOrderItems() != null) {
			       order.getOrderItems().forEach(item -> {
			           // Access book or other lazy fields to trigger loading if needed
			           if (item.getBook() != null) {
			               item.getBook().getTitle(); // Just accessing to trigger fetch
			           }
			       });
			   }
			});
			
			if (orders.isEmpty()) {
			   logger.info("No orders found for user with email: {}", userEmail);
			   // Optionally throw OrderNotFoundException here if you want 404/204 on frontend
			   // For a GET /all type endpoint, returning empty list is common.
			}
			return orders;
	}
}

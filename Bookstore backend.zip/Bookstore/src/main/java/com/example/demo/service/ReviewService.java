package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Review;

public interface ReviewService {
    Review saveReview(Review review);
    Review updateReview(Review review);
    Review patchUpdateReview(Long reviewid, Review updatedFields); // Added this
    Review getReviewById(Long reviewid);
    List<Review> getReviewsByBookId(Long bookid); // Changed to accept Long bookid directly
    List<Review> getReviewsByUserId(Long userid); // Changed to accept Long userid directly
    String deleteReviewById(Long reviewid);
    List<Review> getAllReviews();
}

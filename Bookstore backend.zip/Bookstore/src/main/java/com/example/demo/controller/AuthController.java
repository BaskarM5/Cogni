package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.security.JwtUtil;
import com.example.demo.service.CustomUserDetails;


@RestController
@RequestMapping("/auth")
@CrossOrigin(origins="http://localhost:3000") // Keep this if you prefer endpoint-specific CORS, but global config is primary
public class AuthController {
	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	
	@PostMapping("/login")
	public ResponseEntity<Map<String, String>> login(@RequestBody User user) {
		try {
			// Authenticate the user
			Authentication authentication = authManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
			
			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
			
			// --- Potentially problematic line ---
			String token = jwtUtil.generateToken(userDetails); // This might be throwing an exception
			String role = userDetails.getRole(); 
			
			Map<String, String> response=new HashMap<>();
			response.put("token", token);
			response.put("role", role); 
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			// --- CRUCIAL CHANGE: Print the full stack trace ---
			e.printStackTrace(); // This will show the actual error in your backend console
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error","Invalid email or password"));
		}
	}
}

package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Inventory;
import com.example.demo.service.InventoryService;
import com.example.demo.exception.InventoryNotFoundException;

@RestController
@RequestMapping("api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService service;

    // Save a new inventory record
    @PostMapping
    public ResponseEntity<?> saveInventory(@RequestBody Inventory inventory) {
        try {
            return ResponseEntity.status(201).body(service.saveInventory(inventory));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error saving inventory: " + e.getMessage());
        }
    }

    // Update an existing inventory record
    @PutMapping("/update")
    public ResponseEntity<?> updateInventory(@RequestBody Inventory inventory) {
        try {
            return ResponseEntity.ok(service.updateInventory(inventory));
        } catch (InventoryNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating inventory: " + e.getMessage());
        }
    }

    // Partial update (PATCH) an inventory record
    @PatchMapping("/partial-update/{id}")
    public ResponseEntity<?> patchUpdateInventory(@PathVariable("id") Long inventoryid, @RequestBody Inventory updatedFields) {
        try {
            return ResponseEntity.ok(service.patchUpdateInventory(inventoryid, updatedFields));
        } catch (InventoryNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating inventory: " + e.getMessage());
        }
    }

    // Fetch an inventory record by ID
    @GetMapping("/fetch/{id}")
    public ResponseEntity<?> getInventoryById(@PathVariable("id") Long inventoryid) {
        try {
            return ResponseEntity.ok(service.getInventoryById(inventoryid));
        } catch (InventoryNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    // Fetch an inventory record by BookID
    @GetMapping("/fetch/by-book/{bookid}")
    public ResponseEntity<?> getInventoryByBookId(@PathVariable("bookid") Long bookid) {
        try {
            return ResponseEntity.ok(service.getInventoryByBookid(bookid));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching inventory: " + e.getMessage());
        }
    }

    // Delete an inventory record
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteInventoryById(@PathVariable("id") Long inventoryid) {
        try {
            return ResponseEntity.ok(service.deleteInventoryById(inventoryid));
        } catch (InventoryNotFoundException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }

    // Fetch all inventory records
    @GetMapping("/all")
    public ResponseEntity<List<Inventory>> getAllInventories() {
        return ResponseEntity.ok(service.getAllInventories());
    }
}

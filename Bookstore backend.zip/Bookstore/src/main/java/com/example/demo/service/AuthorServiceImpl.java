package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Author;
import com.example.demo.repository.AuthorRepository;
import com.example.demo.exception.AuthorNotFoundException;

@Service
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private AuthorRepository repository;

    @Override
    public String saveAuthor(Author author) {
        // Here you could add validation, e.g., checking for duplicate author names
        repository.save(author);
        return "Author saved successfully!";
    }

    @Override
    public Author updateAuthor(Author author) {
        // Find existing author to ensure it exists before attempting update
        Optional<Author> existingAuthor = repository.findById(author.getId());
        if (existingAuthor.isPresent()) {
            // For a full PUT update, save the incoming author. JPA will update based on ID.
            return repository.save(author);
        } else {
            throw new AuthorNotFoundException("Author not found for update with ID: " + author.getId());
        }
    }

    @Override
    public Author patchUpdateAuthor(Long id, Author updatedFields) {
        // Find the author by ID for partial update
        return repository.findById(id).map(existingAuthor -> {
            // Apply partial updates if fields are provided
            if (updatedFields.getName() != null && !updatedFields.getName().isEmpty()) {
                existingAuthor.setName(updatedFields.getName());
            }
            if (updatedFields.getBiography() != null) { // Biography can be null, so check explicitly
                existingAuthor.setBiography(updatedFields.getBiography());
            }

            // Save the updated existing author
            return repository.save(existingAuthor);
        }).orElseThrow(() -> new AuthorNotFoundException("Author not found for partial update with ID: " + id));
    }

    @Override
    public Author getAuthorById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException("Author not found with ID: " + id));
    }

    @Override
    public String deleteAuthorById(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return "Author deleted successfully!";
        } else {
            throw new AuthorNotFoundException("Author not found for deletion with ID: " + id);
        }
    }

    @Override
    public List<Author> getAllAuthors() {
        // Returning an empty list if no authors are found is common.
        // You could also throw an exception here if desired, similar to other service methods.
        return repository.findAll();
    }
}

package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne; // Import for ManyToOne
import jakarta.persistence.JoinColumn; // Import for JoinColumn
import jakarta.persistence.Version;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookid;
    private String title;

    // Changed from int authorid to ManyToOne relationship with Author entity
    @ManyToOne
    @JoinColumn(name = "author_id", nullable = false) // Foreign key column in the 'books' table
    private Author author;

    // Changed from int categoryid to ManyToOne relationship with Category entity
    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false) // Foreign key column in the 'books' table
    private Category category;

    private double price;
    private int stockquantity;

    @Lob
    @Column(name = "image_data")
    private byte[] imageData;

    @Column(length = 1000)
    private String description;

    @Version
    private int version;

    // Default Constructor
    public Book() {}

    // Parameterized Constructor - Updated to include Author and Category objects
    public Book(Long bookid, String title, Author author, Category category, double price, int stockquantity, byte[] imageData, String description) {
        this.bookid = bookid;
        this.title = title;
        this.author = author;       // Now takes Author object
        this.category = category;   // Now takes Category object
        this.price = price;
        this.stockquantity = stockquantity;
        this.imageData = imageData;
        this.description = description;
    }

    // Getters and Setters - Ensure all fields have them
    public Long getBookid() {
        return bookid;
    }

    public void setBookid(Long bookid) {
        this.bookid = bookid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Updated Getters and Setters for Author and Category objects
    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStockquantity() {
        return stockquantity;
    }

    public void setStockquantity(int stockquantity) {
        this.stockquantity = stockquantity;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "Book [bookid=" + bookid + ", title=" + title +
               ", author=" + (author != null ? author.getName() : "null") + // Display author name for clarity
               ", category=" + (category != null ? category.getName() : "null") + // Display category name
               ", price=" + price + ", stockquantity=" + stockquantity +
               ", imageData=" + (imageData != null ? "present" : "null") +
               ", description='" + description + '\'' +
               ", version=" + version + "]";
    }
}

package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Author;
import com.example.demo.service.AuthorService;
import com.example.demo.exception.AuthorNotFoundException;

@RestController
@RequestMapping("/api/authors") // Base path for author endpoints
public class AuthorController {

    @Autowired
    private AuthorService service; // Autowire the AuthorService

    // --- Create Author ---
    // POST /api/authors
    @PostMapping
    public ResponseEntity<String> createAuthor(@RequestBody Author author) {
        String message = service.saveAuthor(author);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    // --- Get All Authors ---
    // GET /api/authors
    @GetMapping
    public ResponseEntity<List<Author>> getAllAuthors() {
        List<Author> authors = service.getAllAuthors();
        // Returning 200 OK with an empty list if no authors are found is common.
        return new ResponseEntity<>(authors, HttpStatus.OK);
    }

    // --- Get Author by ID ---
    // GET /api/authors/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getAuthorById(@PathVariable("id") Long id) {
        try {
            Author author = service.getAuthorById(id);
            return new ResponseEntity<>(author, HttpStatus.OK);
        } catch (AuthorNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Update Author (Full Update) ---
    // PUT /api/authors/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> updateAuthor(@PathVariable("id") Long id, @RequestBody Author author) {
        try {
            // Ensure the ID from the path is used for the update
            author.setId(id);
            Author updatedAuthor = service.updateAuthor(author);
            return new ResponseEntity<>(updatedAuthor, HttpStatus.OK);
        } catch (AuthorNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Partially Update Author ---
    // PATCH /api/authors/{id}
    @PatchMapping("/{id}") // A more RESTful path for PATCH, directly on the resource ID
    public ResponseEntity<?> patchUpdateAuthor(@PathVariable("id") Long id, @RequestBody Author updatedFields) {
        try {
            Author patchedAuthor = service.patchUpdateAuthor(id, updatedFields);
            return new ResponseEntity<>(patchedAuthor, HttpStatus.OK);
        } catch (AuthorNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Delete Author by ID ---
    // DELETE /api/authors/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAuthorById(@PathVariable("id") Long id) {
        try {
            String message = service.deleteAuthorById(id);
            return new ResponseEntity<>(message, HttpStatus.OK); // Or HttpStatus.NO_CONTENT
        } catch (AuthorNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}

package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ✅ Save a user
    @Override
    public String saveUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("USER");
        }
        repository.save(user);
        return "User saved successfully!";
    }

    // ✅ Update a user
    @Override
    public User updateUser(User user) {
        Optional<User> existingUserOpt = repository.findById(user.getId()); // Changed to getId()
        if (existingUserOpt.isPresent()) {
            User existing = existingUserOpt.get();

            existing.setName(user.getName() != null ? user.getName() : existing.getName());
            existing.setEmail(user.getEmail() != null ? user.getEmail() : existing.getEmail());
            existing.setRole(user.getRole() != null ? user.getRole() : existing.getRole());
            if (user.getPassword() != null && !user.getPassword().isBlank()) {
                existing.setPassword(passwordEncoder.encode(user.getPassword()));
            }

            return repository.save(existing);
        } else {
            throw new UserNotFoundException("User not found for update with ID: " + user.getId()); // Changed to getId()
        }
    }

    // ✅ Get single user
    @Override
    public User getUserById(Long userId) {
        return repository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));
    }

    // ✅ Delete user
    @Override
    public String deleteUserById(Long userId) {
        if (repository.existsById(userId)) {
            repository.deleteById(userId);
            return "User deleted successfully!";
        } else {
            throw new UserNotFoundException("User not found for deletion with ID: " + userId);
        }
    }

    // ✅ Get all users
    @Override
    public List<User> getAllUsers() {
        return repository.findAll();
    }
}

package com.example.demo.controller;

import com.example.demo.model.Review;
import com.example.demo.service.ReviewService;
import com.example.demo.exception.ReviewNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/review") // Consistent base path
public class ReviewController {

    @Autowired
    private ReviewService service;

    // --- Create Review ---
    @PostMapping("/save") // Consider using just @PostMapping for /api/review
    public ResponseEntity<?> saveReview(@RequestBody Review review) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(service.saveReview(review));
        } catch (Exception e) {
            // General exception for other issues during save, e.g., invalid FKs
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error saving review: " + e.getMessage());
        }
    }

    // --- Update Review (Full Update) ---
    @PutMapping("/update") // Consider @PutMapping("/{id}") for RESTfulness
    public ResponseEntity<?> updateReview(@RequestBody Review review) {
        try {
            return ResponseEntity.ok(service.updateReview(review));
        } catch (ReviewNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            // General exception for other issues during update
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating review: " + e.getMessage());
        }
    }

    // --- Patch Update Review (Partial Update) ---
    @PatchMapping("/partial-update/{id}") // New endpoint for partial update
    public ResponseEntity<?> patchUpdateReview(@PathVariable("id") Long reviewid, @RequestBody Review updatedFields) {
        try {
            return ResponseEntity.ok(service.patchUpdateReview(reviewid, updatedFields));
        } catch (ReviewNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error patching review: " + e.getMessage());
        }
    }


    // --- Get Review by ID ---
    @GetMapping("/fetch/{id}") // Consider using just @GetMapping("/{id}") for RESTfulness
    public ResponseEntity<?> getReviewById(@PathVariable("id") Long reviewid) {
        try {
            return ResponseEntity.ok(service.getReviewById(reviewid));
        } catch (ReviewNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    // --- Delete Review by ID ---
    @DeleteMapping("/delete/{id}") // Consistent with other delete operations
    public ResponseEntity<?> deleteReviewById(@PathVariable("id") Long reviewid) {
        try {
            return ResponseEntity.ok(service.deleteReviewById(reviewid));
        } catch (ReviewNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    // --- Get All Reviews ---
    @GetMapping("/all") // Consistent with other getAll operations
    public ResponseEntity<List<Review>> getAllReviews() {
        // Service's getAllReviews does not throw NotFoundException for empty list,
        // so no try-catch needed here if you want empty list for 200 OK
        return ResponseEntity.ok(service.getAllReviews());
    }

    // --- Get Reviews by Book ID ---
    @GetMapping("/by-book/{bookId}") // New endpoint for reviews by book
    public ResponseEntity<List<Review>> getReviewsByBookId(@PathVariable("bookId") Long bookId) {
        List<Review> reviews = service.getReviewsByBookId(bookId);
        return reviews.isEmpty() ? ResponseEntity.status(HttpStatus.NO_CONTENT).build() : ResponseEntity.ok(reviews);
    }

    // --- Get Reviews by User ID ---
    @GetMapping("/by-user/{userId}") // New endpoint for reviews by user
    public ResponseEntity<List<Review>> getReviewsByUserId(@PathVariable("userId") Long userId) {
        List<Review> reviews = service.getReviewsByUserId(userId);
        return reviews.isEmpty() ? ResponseEntity.status(HttpStatus.NO_CONTENT).build() : ResponseEntity.ok(reviews);
    }
}

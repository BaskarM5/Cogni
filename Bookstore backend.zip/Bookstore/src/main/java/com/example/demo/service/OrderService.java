package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Order;

public interface OrderService {
    String saveOrder(Order order);
    Order updateOrder(Order order);
    Order getOrderById(Long orderid); // Changed to Long
    String deleteOrderById(Long orderid); // Changed to Long
    List<Order> getAllOrders();
    Order patchUpdateOrder(Long orderid, Order updatedFields); // Changed to Long
    List<Order> getOrdersByUserEmail(String userEmail);
}

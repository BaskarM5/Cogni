package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Category;
import com.example.demo.service.CategoryService;
import com.example.demo.exception.CategoryNotFoundException;

@RestController
@RequestMapping("/api/categories") // Base path for category endpoints
public class CategoryController {

    @Autowired
    private CategoryService service; // Autowire the CategoryService

    // --- Create Category ---
    // POST /api/categories
    @PostMapping
    public ResponseEntity<String> createCategory(@RequestBody Category category) {
        String message = service.saveCategory(category);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }

    // --- Get All Categories ---
    // GET /api/categories
    @GetMapping
    public ResponseEntity<List<Category>> getAllCategories() {
        List<Category> categories = service.getAllCategories();
        // Returning 200 OK with an empty list if no categories are found is common.
        // If service throws CategoryNotFoundException when empty, handle it here.
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    // --- Get Category by ID ---
    // GET /api/categories/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getCategoryById(@PathVariable("id") Long id) {
        try {
            Category category = service.getCategoryById(id);
            return new ResponseEntity<>(category, HttpStatus.OK);
        } catch (CategoryNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Update Category (Full Update) ---
    // PUT /api/categories/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> updateCategory(@PathVariable("id") Long id, @RequestBody Category category) {
        try {
            // Ensure the ID from the path is used for the update
            category.setId(id);
            Category updatedCategory = service.updateCategory(category);
            return new ResponseEntity<>(updatedCategory, HttpStatus.OK);
        } catch (CategoryNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Partially Update Category ---
    // PATCH /api/categories/{id}
    @PatchMapping("/{id}") // A more RESTful path for PATCH, directly on the resource ID
    public ResponseEntity<?> patchUpdateCategory(@PathVariable("id") Long id, @RequestBody Category updatedFields) {
        try {
            Category patchedCategory = service.patchUpdateCategory(id, updatedFields);
            return new ResponseEntity<>(patchedCategory, HttpStatus.OK);
        } catch (CategoryNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // --- Delete Category by ID ---
    // DELETE /api/categories/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCategoryById(@PathVariable("id") Long id) {
        try {
            String message = service.deleteCategoryById(id);
            return new ResponseEntity<>(message, HttpStatus.OK); // Or HttpStatus.NO_CONTENT
        } catch (CategoryNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}

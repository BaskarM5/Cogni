package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import com.example.demo.exception.BookNotFoundException;
import com.example.demo.exception.AuthorNotFoundException; // Import AuthorNotFoundException
import com.example.demo.exception.CategoryNotFoundException; // Import CategoryNotFoundException


@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService service;

    // Create a new book
    // Maps to POST /api/books
    @PostMapping
    public ResponseEntity<String> saveBook(@RequestBody Book book) {
        try {
            // Jackson will automatically deserialize the JSON request body into a Book object,
            // handling all fields including 'imageData' (as Base64 string), 'description',
            // and nested Author/Category objects (with at least their IDs set).
            String message = service.saveBook(book);
            return new ResponseEntity<>(message, HttpStatus.CREATED);
        } catch (AuthorNotFoundException | CategoryNotFoundException e) {
            // Catch specific exceptions for invalid associated entities (Author/Category)
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); // Returns 400 Bad Request
        } catch (Exception e) {
            // Catch any other unexpected exceptions during save
            return new ResponseEntity<>("Error saving book: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get all books
    // Maps to GET /api/books or /api/books/all
    @GetMapping("/all")
    public ResponseEntity<List<Book>> getAllBooks() {
        // Json will automatically serialize nested Author and Category objects,
        // 'imageData' (to Base64 string), and 'description' when returning the list of Book objects as JSON.
        List<Book> allBooks = service.getAllBooks();
        return new ResponseEntity<>(allBooks, HttpStatus.OK);
    }

    // Get book by ID
    // Maps to GET /api/books/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable("id") Long bookid) {
        try {
            // Jackson will automatically serialize nested Author and Category objects,
            // 'imageData' (to Base64 string), and 'description' when returning the Book object as JSON.
            Book book = service.getBookById(bookid);
            return new ResponseEntity<>(book, HttpStatus.OK);
        } catch (BookNotFoundException e) {
            // Catch specific exception if the book is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND); // Returns 404 Not Found
        } catch (Exception e) {
            // Catch any other unexpected exceptions during fetch
            return new ResponseEntity<>("Error fetching book: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Update book completely
    // Maps to PUT /api/books/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable("id") Long id, @RequestBody Book book) {
        try {
            book.setBookid(id); // Ensure the ID from the path is set on the book object
            // Jackson will automatically deserialize the JSON request body into a Book object,
            // handling all fields including 'imageData', 'description', and nested Author/Category objects.
            Book updatedBook = service.updateBook(book);
            return new ResponseEntity<>(updatedBook, HttpStatus.OK);
        } catch (BookNotFoundException e) {
            // Catch specific exception if the book to update is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND); // Returns 404 Not Found
        } catch (AuthorNotFoundException | CategoryNotFoundException e) {
            // Catch specific exceptions for invalid associated entities during update
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); // Returns 400 Bad Request
        } catch (Exception e) {
            // Catch any other unexpected exceptions during update
            return new ResponseEntity<>("Error updating book: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Delete book by ID
    // Maps to DELETE /api/books/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBookById(@PathVariable("id") Long bookid) {
        try {
            String message = service.deleteBookById(bookid);
            return new ResponseEntity<>(message, HttpStatus.OK); // Returns 200 OK for successful deletion
        } catch (BookNotFoundException e) {
            // Catch specific exception if the book to delete is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND); // Returns 404 Not Found
        } catch (Exception e) {
            // Catch any other unexpected exceptions during deletion
            return new ResponseEntity<>("Error deleting book: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Partial update with PATCH
    // Maps to PATCH /api/books/partial-update/{id}
    @PatchMapping("/partial-update/{id}")
    public ResponseEntity<?> patchUpdateBook(@PathVariable("id") Long bookid, @RequestBody Book updatedFields) {
        try {
            // Jackson will automatically deserialize the JSON request body into a Book object,
            // handling 'imageData' (as Base64 string), 'description', and nested Author/Category objects if provided.
            // The service method will then apply these partial updates.
            Book updatedBook = service.patchUpdateBook(bookid, updatedFields);
            return new ResponseEntity<>(updatedBook, HttpStatus.OK);
        } catch (BookNotFoundException e) {
            // Catch specific exception if the book to patch is not found
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND); // Returns 404 Not Found
        } catch (AuthorNotFoundException | CategoryNotFoundException e) {
            // Catch specific exceptions for invalid associated entities during patch update
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); // Returns 400 Bad Request
        } catch (Exception e) {
            // Catch any other unexpected exceptions during patch update
            return new ResponseEntity<>("Error patching book: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ReviewNotFoundException;
import com.example.demo.exception.BookNotFoundException; // Import for BookNotFoundException
import com.example.demo.exception.UserNotFoundException; // Import for UserNotFoundException
import com.example.demo.model.Review;
import com.example.demo.model.User; // Import User model
import com.example.demo.model.Book; // Import Book model
import com.example.demo.repository.ReviewRepository;
import com.example.demo.repository.UserRepository; // Autowire UserRepository
import com.example.demo.repository.BookRepository; // Autowire BookRepository

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository repository;

    @Autowired
    private UserRepository userRepository; // Autowire UserRepository

    @Autowired
    private BookRepository bookRepository; // Autowire BookRepository

    @Override
    public Review saveReview(Review review) {
        // 1. Fetch and validate User entity
        User user = userRepository.findById(review.getUser().getId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + review.getUser().getId()));
        review.setUser(user); // Set the managed User entity

        // 2. Fetch and validate Book entity
        Book book = bookRepository.findById(review.getBook().getBookid())
                .orElseThrow(() -> new BookNotFoundException("Book not found with ID: " + review.getBook().getBookid()));
        review.setBook(book); // Set the managed Book entity

        // 3. Optional: Add validation for rating range (e.g., 1 to 5)
        if (review.getRating() < 1 || review.getRating() > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5.");
        }

        return repository.save(review);
    }

    @Override
    public Review updateReview(Review review) {
        return repository.findById(review.getReviewid())
                .map(existingReview -> {
                    // Update User association if provided
                    if (review.getUser() != null && review.getUser().getId() != null) {
                        User user = userRepository.findById(review.getUser().getId())
                                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + review.getUser().getId()));
                        existingReview.setUser(user);
                    }

                    // Update Book association if provided
                    if (review.getBook() != null && review.getBook().getBookid() != null) {
                        Book book = bookRepository.findById(review.getBook().getBookid())
                                .orElseThrow(() -> new BookNotFoundException("Book not found with ID: " + review.getBook().getBookid()));
                        existingReview.setBook(book);
                    }

                    existingReview.setRating(review.getRating());
                    existingReview.setComment(review.getComment());

                    // Optional: Add validation for rating range (e.g., 1 to 5)
                    if (existingReview.getRating() < 1 || existingReview.getRating() > 5) {
                        throw new IllegalArgumentException("Rating must be between 1 and 5.");
                    }

                    return repository.save(existingReview);
                }).orElseThrow(() -> new ReviewNotFoundException("Review not found with ID: " + review.getReviewid()));
    }

    @Override
    public Review patchUpdateReview(Long reviewid, Review updatedFields) {
        return repository.findById(reviewid).map(existingReview -> {
            if (updatedFields.getBook() != null && updatedFields.getBook().getBookid() != null) {
                // Fetch the actual Book entity to ensure it's managed
                Book book = bookRepository.findById(updatedFields.getBook().getBookid())
                        .orElseThrow(() -> new BookNotFoundException("Book not found with ID: " + updatedFields.getBook().getBookid()));
                existingReview.setBook(book);
            }
            if (updatedFields.getUser() != null && updatedFields.getUser().getId() != null) {
                // Fetch the actual User entity to ensure it's managed
                User user = userRepository.findById(updatedFields.getUser().getId())
                        .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + updatedFields.getUser().getId()));
                existingReview.setUser(user);
            }
            if (updatedFields.getRating() > 0) { // Check for meaningful update, but also validate range
                // Consider adding validation for rating range (e.g., 1 to 5)
                if (updatedFields.getRating() < 1 || updatedFields.getRating() > 5) {
                    throw new IllegalArgumentException("Rating must be between 1 and 5.");
                }
                existingReview.setRating(updatedFields.getRating());
            }
            if (updatedFields.getComment() != null) {
                existingReview.setComment(updatedFields.getComment());
            }
            return repository.save(existingReview);
        }).orElseThrow(() -> new ReviewNotFoundException("Review not found with ID: " + reviewid));
    }

    @Override
    public Review getReviewById(Long reviewid) {
        return repository.findById(reviewid)
                .orElseThrow(() -> new ReviewNotFoundException("Review not found with ID: " + reviewid));
    }

    @Override
    public List<Review> getReviewsByBookId(Long bookid) {
        // Now directly uses the modified repository method
        return repository.findByBook_Bookid(bookid);
    }

    @Override
    public List<Review> getReviewsByUserId(Long userid) {
        // Now directly uses the modified repository method
        return repository.findByUser_Id(userid);
    }

    @Override
    public String deleteReviewById(Long reviewid) {
        if (!repository.existsById(reviewid)) {
            throw new ReviewNotFoundException("Review not found with ID: " + reviewid);
        }
        repository.deleteById(reviewid);
        return "Review deleted successfully!";
    }

    @Override
    public List<Review> getAllReviews() {
        return repository.findAll();
    }
}

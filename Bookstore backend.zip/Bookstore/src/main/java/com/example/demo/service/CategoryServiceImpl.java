package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Category;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.exception.CategoryNotFoundException;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository repository;

    @Override
    public String saveCategory(Category category) {
        // Here you could add validation, e.g., check if a category with the same name already exists
        repository.save(category);
        return "Category saved successfully!";
    }

    @Override
    public Category updateCategory(Category category) {
        // Find existing category to ensure it exists before attempting update
        Optional<Category> existingCategory = repository.findById(category.getId());
        if (existingCategory.isPresent()) {
            // Since all fields are provided in a PUT, we can just save the incoming category
            // This will update the existing record based on the ID.
            return repository.save(category);
        } else {
            throw new CategoryNotFoundException("Category not found for update with ID: " + category.getId());
        }
    }

    @Override
    public Category patchUpdateCategory(Long id, Category updatedFields) {
        // Find the category by ID
        return repository.findById(id).map(existingCategory -> {
            // Apply partial updates if fields are provided
            if (updatedFields.getName() != null && !updatedFields.getName().isEmpty()) {
                existingCategory.setName(updatedFields.getName());
            }
            // Add other fields here if Category model gets more fields that can be patched

            // Save the updated existing category
            return repository.save(existingCategory);
        }).orElseThrow(() -> new CategoryNotFoundException("Category not found for partial update with ID: " + id));
    }

    @Override
    public Category getCategoryById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with ID: " + id));
    }

    @Override
    public String deleteCategoryById(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return "Category deleted successfully!";
        } else {
            throw new CategoryNotFoundException("Category not found for deletion with ID: " + id);
        }
    }

    @Override
    public List<Category> getAllCategories() {
        // You might consider throwing an exception or returning an empty list
        // based on your API design when no categories are found.
        return repository.findAll();
    }
}

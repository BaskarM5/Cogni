package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.InsufficientStockException; // Import new exception
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.Order;
import com.example.demo.service.OrderService;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private OrderService service;

    @PostMapping
    public ResponseEntity<String> saveOrder(@RequestBody Order order) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(service.saveOrder(order));
        } catch (InsufficientStockException e) {
            logger.error("Insufficient stock for order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()); // 400 for stock issues
        } catch (Exception e) {
            logger.error("Error saving order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving order: " + e.getMessage());
        }
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateOrder(@RequestBody Order order) {
        try {
            return ResponseEntity.ok(service.updateOrder(order));
        } catch (OrderNotFoundException e) {
            logger.warn("Order not found for update: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error updating order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating order: " + e.getMessage());
        }
    }

    @PatchMapping("/partial-update/{id}")
    public ResponseEntity<?> patchUpdateOrder(@PathVariable("id") Long orderId, @RequestBody Order updatedFields) { // Changed to Long
        try {
            // Note: Stock adjustments for partial updates are complex and not handled here.
            // This only updates scalar fields of the Order.
            return ResponseEntity.ok(service.patchUpdateOrder(orderId, updatedFields));
        } catch (OrderNotFoundException e) {
            logger.warn("Order not found for partial update: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error patch updating order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating order: " + e.getMessage());
        }
    }

    @GetMapping("/fetch/{id}")
    public ResponseEntity<?> getOrderById(@PathVariable("id") Long orderId) { // Changed to Long
        try {
            return ResponseEntity.ok(service.getOrderById(orderId));
        } catch (OrderNotFoundException e) {
            logger.warn("Order not found for fetch: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error fetching order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error fetching order: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteOrderById(@PathVariable("id") Long orderId) { // Changed to Long
        try {
            return ResponseEntity.ok(service.deleteOrderById(orderId));
        } catch (OrderNotFoundException e) {
            logger.warn("Order not found for deletion: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error deleting order: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting order: " + e.getMessage());
        }
    }
    
    @GetMapping("/user/{userEmail}")
    public ResponseEntity<?> getOrdersByUserEmail(@PathVariable String userEmail) {
        try {
            List<Order> userOrders = service.getOrdersByUserEmail(userEmail);
            if (userOrders.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
            }
            return ResponseEntity.ok(userOrders);
        } catch (UserNotFoundException e) {
            logger.warn("User not found for order retrieval: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) { // Catch other potential exceptions from service
            logger.error("Error fetching orders for user {}: {}", userEmail, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error fetching user orders: " + e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Order>> getAllOrders() {
        try {
            List<Order> allOrders = service.getAllOrders();
            // Changed from NO_CONTENT to OK with empty list if no orders found,
            // as service now throws OrderNotFoundException if no orders are found.
            return ResponseEntity.ok(allOrders); 
        } catch (OrderNotFoundException e) { // Catch the specific exception from service
            logger.info("No orders found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null); // Or return an empty list with 200 OK
        } catch (Exception e) {
            logger.error("Error fetching orders: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}

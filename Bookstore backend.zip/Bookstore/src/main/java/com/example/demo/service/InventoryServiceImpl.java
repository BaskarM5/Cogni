package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Inventory;
import com.example.demo.repository.InventoryRepository;
import com.example.demo.exception.InventoryNotFoundException;

@Service
public class InventoryServiceImpl implements InventoryService {

    @Autowired
    private InventoryRepository repository;

    @Override
    public Inventory saveInventory(Inventory inventory) {
        return repository.save(inventory);
    }

    @Override
    public Inventory updateInventory(Inventory inventory) {
        return repository.findById(inventory.getInventoryid())
                .map(existingInventory -> {
                    existingInventory.setBook(inventory.getBook());
                    existingInventory.setQuantity(inventory.getQuantity());
                    return repository.save(existingInventory);
                }).orElseThrow(() -> new InventoryNotFoundException("Inventory not found with ID: " + inventory.getInventoryid()));
    }

    @Override
    public Inventory patchUpdateInventory(Long inventoryid, Inventory updatedFields) {
        return repository.findById(inventoryid).map(existingInventory -> {
            if (updatedFields.getBook() != null) {
                existingInventory.setBook(updatedFields.getBook());
            }
            if (updatedFields.getQuantity() > 0) {
                existingInventory.setQuantity(updatedFields.getQuantity());
            }
            return repository.save(existingInventory);
        }).orElseThrow(() -> new InventoryNotFoundException("Inventory not found with ID: " + inventoryid));
    }

    @Override
    public Inventory getInventoryById(Long inventoryid) {
        return repository.findById(inventoryid)
                .orElseThrow(() -> new InventoryNotFoundException("Inventory not found with ID: " + inventoryid));
    }

    @Override
    public Optional<Inventory> getInventoryByBookid(Long bookid) { // Fixed method name
        return repository.findByBook_Bookid(bookid); // Ensured consistency
    }

    @Override
    public String deleteInventoryById(Long inventoryid) {
        if (!repository.existsById(inventoryid)) {
            throw new InventoryNotFoundException("Inventory not found with ID: " + inventoryid);
        }
        repository.deleteById(inventoryid);
        return "Inventory deleted successfully!";
    }

    @Override
    public List<Inventory> getAllInventories() {
        return repository.findAll();
    }
}

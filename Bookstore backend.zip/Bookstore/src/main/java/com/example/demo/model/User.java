package com.example.demo.model; // Ensure this matches your package structure

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users") // Assuming your user table is named 'users'
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key for the User

    @Column(nullable = false, length = 100)
    private String name; // User's full name

    @Column(nullable = false, unique = true, length = 100)
    private String email; // User's email (often used as username)

    @Column(nullable = false)
    private String password; // Hashed password

    @Column(nullable = false, length = 20)
    private String role; // User's role (e.g., "ADMIN", "USER")

    // IMPORTANT: Public no-argument constructor is required by JPA and Jackson for deserialization
    public User() {
    }

    // Parameterized Constructor (useful for creating User objects programmatically)
    public User(Long id, String name, String email, String password, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    
    // Minimal constructor for deserialization when only email is provided (like in Order payload)
    public User(String email) {
        this.email = email;
    }

    // Getters and Setters for all fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) { // Crucial setter for Jackson deserialization
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "User{" +
               "id=" + id +
               ", name='" + name + '\'' +
               ", email='" + email + '\'' +
               ", role='" + role + '\'' +
               '}';
    }
}
